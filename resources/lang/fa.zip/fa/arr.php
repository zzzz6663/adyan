<?php
return [
    'staff' => ' کارمند',
    'free' => ' آزاد',
    'none' => 'هیچکدام ',
    'manager' => 'مدیر گروه ',
    'expert' => 'کارشناس ',
    'admin' => ' ادمین',
    'student' => ' دانشجو',
    'master' => ' استاد',
    'progress' => 'در حال بررسی ',
    'register' => ' ثبت نام  ',
    'verify' => '  تایید حساب',
    'submit_curt' => '  ثبت طرح اجمالی   ',
    '' => '     ',
    '' => '     ',



];

?>
