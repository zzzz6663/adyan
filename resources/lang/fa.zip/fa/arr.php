<?php
return [
    'staff' => ' کارمند',
    'free' => ' آزاد',
    'none' => 'هیچکدام ',
    'manager' => 'مدیر گروه ',
    'expert' => 'کارشناس ',
    'admin' => ' ادمین',
    'student' => ' دانشجو',
    'master' => ' استاد',
    'progress' => 'در حال بررسی ',
    'register' => ' ثبت نام  ',
    'verify' => '  تایید حساب',
    'submit_curt' => '  ثبت طرح اجمالی   ',
    'edit_curt_by_student' => '   ویرایش توسط دانشجو  ',
    'faild' => '   رد شده  ',
    'accept_with_guid_without_plan'=> '  نایید شده با استاد راهنما بدون طرح تفصیلی   ',
    'accept_with_guid_with_plan'=> '  نایید شده با استاد راهنما با طرح تفصیلی   ',
    'accept_without_guid' => '   تایید شده بدون استاد راهنما  ',
    'review_curt_by_master' => 'بررسی توسط گروه     ',
    'accept' => '     تایید شده',
    'verify_by_group' => '   بررسی توسط گروه   ',
    'reject' => '     رد شده ',
    '' => '     ',
    '' => '     ',
    '' => '     ',
    '' => '     ',
    '' => '     ',



];

?>
