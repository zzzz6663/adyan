<?php
return [
    'staff' => ' الموظف',
    'free' => ' الحر',
    'none' => 'لا أحد ',
    'manager' => 'مدیر اللجنة ',
    'expert' => 'الضابط ',
    'admin' => ' مدیر المنصة',
    'student' => ' الطالب',
    'master' => ' استاذ',
    'progress' => 'قید النظر ',
    'register' => ' ثبت نام ',
    'verify' => '  تأکید الحساب',
    'submit_curt' => '  تسجیل الاستمارة الاولی  ',
    'edit_curt_by_student' => '   التعدیل من قبل الطالب  ',
    'faild' => '   مرفوض  ',
    'accept_with_guid_without_plan'=> '  نایید شده با استاد راهنما بدون طرح تفصیلی   ',
    'accept_with_guid_with_plan'=> '  نایید شده با استاد راهنما با طرح تفصیلی   ',
    'accept_without_guid' => '   تایید شده بدون استاد راهنما  ',
    'review_curt_by_master' => 'قید النظر في اللجنة ',
    'accept' => '     تمت الموافقة',
    'verify_by_group' => '   قید النظر في اللجنة   ',
    'reject' => '     مرفوض ',
    'accept_without_master' => '     تمت الموافقة علی الاستمارة الاولی دون المشرف',
    'review_plan_by_group' => '  برررسی توسط گروه   ',
    '' => '     ',
    '' => '     ',
    '' => '     ',



];

?>
