@extends('email.master')
@section('message')
{{$title}} :
{{$payam}}

@endsection
