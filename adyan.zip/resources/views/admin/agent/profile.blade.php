@extends('master.main')
{{-- @php($side=true) --}}
@section('main')
<!--begin::Content-->
 @include('admin.agent.profile_info')
@endsection
