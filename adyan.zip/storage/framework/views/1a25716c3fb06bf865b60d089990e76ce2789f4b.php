<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <?php if(isset($group) && $group->id): ?>
                <div class="col-xxl-12 order-2 order-xxl-1">
                    <!--begin::پیشرفت Table Widget 2-->
                    <div class="card card-custom card-stretch gutter-b">
                        <!--begin::Header-->
                        <div class="card-header border-0 pt-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark"> <?php echo e(__('sentences.select_curt')); ?>  </span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm"> </span>
                            </h3>

                        </div>
                        <!--end::Header-->

                        <!--begin::Body-->
                        <div class="card-body pt-3 pb-0">
                            <!--begin::Table-->
                            <div class="table-responsive">
                                <!--begin: جدول داده ها-->
                             <!--begin: جدول داده ها-->
                             <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                             id="kt_datatable" style="">
                             <table class="datatable-table" style="display: block;">
                                 <thead class="datatable-head">
                                     <tr class="datatable-row" style="left: 0px;">

                                         <th class="datatable-cell datatable-cell-sort text-center">
                                             <span>
                                                 <?php echo e(__('sentences.id')); ?>

                                             </span>
                                         </th>

                                         <th class="datatable-cell datatable-cell-sort text-center">
                                             <span>
                                                 <?php echo e(__('sentences.title')); ?>

                                             </span>
                                         </th>
                                         <th class="datatable-cell datatable-cell-sort text-center">
                                             <span>
                                                 <?php echo e(__('sentences.student')); ?>

                                             </span>
                                         </th>
                                         <th class="datatable-cell datatable-cell-sort text-center">
                                             <span>
                                                 <?php echo e(__('sentences.last_change_student_date')); ?>


                                             </span>
                                         </th>
                                         <th class="datatable-cell datatable-cell-sort text-center">
                                             <span>
                                                 <?php echo e(__('sentences.created_at')); ?>

                                             </span>
                                         </th>

                                     </tr>
                                 </thead>
                                 <tbody class="datatable-body" style="">
                                     <?php $__currentLoopData = $group->curts()->whereType('primary')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mastercrut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr class="datatable-row" style="left: 0px;">
                                         <td class="datatable-cell text-center">
                                             <span><?php echo e($loop->iteration); ?> </span>
                                         </td>
                                         <td class="datatable-cell text-center">
                                             <span><?php echo e($mastercrut->title); ?> </span>
                                         </td>
                                         <td class="datatable-cell text-center">
                                             <span>
                                                 <?php echo e($mastercrut->user->name); ?>

                                                 <?php echo e($mastercrut->user->family); ?>

                                              </span>
                                         </td>
                                         <td class="datatable-cell text-center">
                                             <span>
                                                 <?php if($last_curt=$mastercrut->user->curts()->latest()->first()): ?>

                                                 <?php echo e(Morilog\Jalali\Jalalian::forge($last_curt->created_at)->format('Y-m-d')); ?>

                                             <?php endif; ?>

                                             </span>
                                         </td>


                                         <td class="datatable-cell text-center">
                                             <span><?php echo e(Morilog\Jalali\Jalalian::forge($mastercrut->created_at)->format('Y-m-d')); ?>

                                             </span>
                                         </td>
                                         
                                     </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                 </tbody>
                             </table>


                         </div>
                         <!--end: جدول داده ها-->
                                <!--end: جدول داده ها-->
                            </div>
                            <!--end::Table-->
                        </div>
                        <!--end::Body-->


                        <div class="card-header border-0 pt-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark"> <?php echo e(__('sentences.my_plan')); ?>  </span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm"> </span>
                            </h3>

                        </div>
                        <div class="card-body pt-3 pb-0">
                                <!--begin: جدول داده ها-->
                                <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                id="kt_datatable" style="">
                                <table class="datatable-table" style="display: block;">
                                    <thead class="datatable-head">
                                        <tr class="datatable-row" style="left: 0px;">

                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.id')); ?>

                                                </span>
                                            </th>

                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.title')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.student')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.last_change_student_date')); ?>


                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.created_at')); ?>


                                                </span>
                                            </th>

                                        </tr>
                                    </thead>
                                    <tbody class="datatable-body" style="">
                                        <?php $__currentLoopData = $group->plans()->whereType('primary')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $masterplan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="datatable-row" style="left: 0px;">
                                            <td class="datatable-cell text-center">
                                                <span><?php echo e($loop->iteration); ?> </span>
                                            </td>
                                            <td class="datatable-cell text-center">
                                                <span><?php echo e($masterplan->title); ?> </span>
                                            </td>
                                            <td class="datatable-cell text-center">
                                                <span>
                                                    <?php echo e($masterplan->user->name); ?>

                                                    <?php echo e($masterplan->user->family); ?>

                                                 </span>
                                            </td>
                                            <td class="datatable-cell text-center">
                                                <span>
                                                    <?php if($last_plan=$masterplan->user->plans()->latest()->first()): ?>

                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($last_plan->created_at)->format('Y-m-d')); ?>

                                                <?php endif; ?>

                                                </span>
                                            </td>


                                            <td class="datatable-cell text-center">
                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($masterplan->created_at)->format('Y-m-d')); ?>

                                                </span>
                                            </td>
                                            
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                </table>


                            </div>
                            <!--end: جدول داده ها-->
                        </div>
                    </div>
                    <!--end::پیشرفت Table Widget 2-->
                </div>
                <div class="col-xxl-12 order-2 order-xxl-1 mt-2">
                    <div class="col-lg-6">
                       <div class="card card-custom  card-stretch gutter-b">
                           <!--begin::Header-->
                           <div class="card-header h-auto border-0">
                               <div class="card-title py-5">
                                   <h3 class="card-label">
                                       <span class="d-block text-dark font-weight-bolder">   <?php echo e(__('sentences.pending_log')); ?></span>

                                   </h3>
                               </div>

                           </div>
                           <!--end::Header-->

                           <!--begin::Body-->
                           <div class="card-body">
                               <div id="amamr2" data-amar="<?php echo e(json_encode([$curts->count(),$plans->count(),$subjects->count()])); ?>" ></div>
                           </div>
                           <!--end::Body-->
                       </div>
                    </div>
                       <!--end::نمودار Widget 4-->
                   </div>
                <?php else: ?>
                <div class="col-xxl-12 order-2 order-xxl-1">
                    <!--begin::پیشرفت Table Widget 2-->
                    <div class="card card-custom card-stretch gutter-b">
                        <!--begin::Header-->
                        <div class="card-header border-0 pt-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark"> <?php echo e(__('sentences.select_group_show')); ?>  </span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm"> </span>
                            </h3>

                        </div>
                        <!--end::Header-->

                        <!--begin::Body-->
                        <div class="card-body pt-3 pb-0">
                            <form action="<?php echo e(route('admin.group.mission')); ?>" method="get">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('get'); ?>
                                <div class="row">
                                    <div class="col-xl-6">
                                            <!--begin::ورودی-->
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>       <?php echo e(__('sentences.select_group')); ?>    </label>
                                                <select name="group_id" id="ostad" class="form-control  ">
                                                    <option value="">           <?php echo e(__('sentences.select_one')); ?> </option>
                                                    <?php $__currentLoopData = App\Models\Group::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e(old('group_id')==$group->id?'selected':''); ?> value="<?php echo e($group->id); ?>">
                                                        <?php echo e(__('sentences.group')); ?>

                                                        <?php echo e($group->name); ?>

                                                      (
                                                        <?php echo e(__('sentences.manager')); ?>:
                                                          <?php echo e($group->admin()->name); ?>

                                                          <?php echo e($group->admin()->family); ?>

                                                      )
                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <!--end::ورودی-->
                                        </div>
                                        <div class="col-xl-6">
                                        </div>
                                </div>
                                <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                    
                                    <div>
                                        <input type="submit" value="     <?php echo e(__('sentences.save')); ?>   "
                                            class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                            

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>




            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/group/group_mission.blade.php ENDPATH**/ ?>