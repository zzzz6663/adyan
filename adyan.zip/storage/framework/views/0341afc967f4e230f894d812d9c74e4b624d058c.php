<?php $__env->startSection('main'); ?>
    <!--begin::Content-->
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class=" container ">


                <div class="row">
                    <div class="col-lg-12 order-1 order-xxl-2">
                        <div class="card card-custom card-stretch gutter-b">
                            <!--begin::Header-->
                            <div class="card-header border-0">
                                <h3 class="card-title font-weight-bolder text-dark">
                                    <?php echo e(__('sentences.notes')); ?>



                                </h3>

                            </div>
                            <!--end::Header-->

                            <!--begin::Body-->

                            <div class="card-body pt-0">
                                <ul>
                                    <li>
                                        <?php echo e(__('sentences.note6')); ?>

                                    </li>
                                    <li>  <?php echo e(__('sentences.note7')); ?> </li>
                                    <li>  <?php echo e(__('sentences.note8')); ?>  </li>
                                    <li>   <?php echo e(__('sentences.note9')); ?> </li>
                                    <li>   <?php echo e(__('sentences.note10')); ?> </li>
                                </ul>

                                <a class="btn  btn-primary" href="<?php echo e(route('curt.create')); ?>"><?php echo e(__('sentences.create_curt')); ?></a>
                                <span class="btn  btn-success"  id="show_tags"><?php echo e(__('sentences.select_curt')); ?></span>



                                


                            </div>
                            <?php echo $__env->make('sections.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div id="tags_section" class="card-body pt-0  <?php echo e($errors->any()?'':'hide'); ?>" >
                                <ul>
                                  <li>  <?php echo e(__('sentences.note12')); ?> </li>
                                  <li>  <?php echo e(__('sentences.note13')); ?>  </li>
                                  <li>   <?php echo e(__('sentences.note14')); ?> </li>
                                  <li>   <?php echo e(__('sentences.note15')); ?> </li>
                                </ul>



                                <form class="form" action="<?php echo e(route('student.subject.list')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('post'); ?>
                                  <div class="row">
                                    <div class="col-lg-6">
                                        <!--begin::ورودی-->
                                        <div class="form-group fv-plugins-icon-container">
                                            <label>       <?php echo e(__('sentences.tags')); ?>    </label>
                                            <select style="width:500px" name="tags[]" id="" class="form-control select2" multiple="multiple">
                                                <option disabled="disabled" value=""><?php echo e(__('sentences.select_one')); ?></option>
                                                <?php $__currentLoopData = App\Models\Tag::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(in_array($tag->id ,old('tags',[]))?'selected':''); ?> value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag); ?></option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <!--end::ورودی-->
                                    </div>
                                  </div>
                                  <input type="submit" class="btn btn-success" value=" <?php echo e(__('sentences.select_tags')); ?> ">
                              </form>
                              </div>
                            <!--end::Body-->
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Container-->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/student/per_curt.blade.php ENDPATH**/ ?>