<div class="card-body">


    <!--begin: جدول داده ها-->
    <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
        id="kt_datatable" style="">
        <h1> <?php echo e(__('sentences.session_curts')); ?></h1>
        <table class="datatable-table" style="display: block;">
            <thead class="datatable-head">
                <tr class="datatable-row" style="left: 0px;">
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.id')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.title')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.student')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.master')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.status')); ?>

                        </span>
                    </th>

                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.created_at')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.action')); ?>

                        </span>
                    </th>


                </tr>
            </thead>
            <tbody class="datatable-body" style="">
                <?php $__currentLoopData = $session->curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="datatable-row" style="left: 0px;">
                        <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?> </span></td>
                        <td class="datatable-cell text-center"><span><?php echo e($curt->title); ?> </span></td>
                        <td class="datatable-cell text-center">
                           <a href="<?php echo e(route('agent.profile',$curt->user->id)); ?>">
                            <span>
                                <?php echo e($curt->user->name); ?>

                                <?php echo e($curt->user->family); ?>

                            </span>
                           </a>
                        </td>

                        <td class="datatable-cell text-center"><span><?php echo e(__('arr.' . $curt->level)); ?>

                            </span>
                        </td>
                        <td class="datatable-cell text-center">
                            <span><?php echo e($curt->status=='accept'?           __('sentences.accept'):   __('sentences.reject')); ?>

                            </span>
                        </td>
                        <td class="datatable-cell text-center">
                            <span><?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('Y-m-d')); ?>

                            </span>
                        </td>

                        <?php if($show_actions): ?>
                        <td class="datatable-cell text-center">
                            <?php if($curt->side): ?>
                            <span class="text  text-success">
                                <?php echo e(__('sentences.verified')); ?>

                            </span>
                        <?php else: ?>
                        <a class="btn btn-outline-primary"
                        href="<?php echo e(route('admin.show.curt', $curt->id)); ?>"><?php echo e(__('sentences.verify')); ?></a>
                        <?php endif; ?>

                        </td>
                        <?php endif; ?>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
        </table>


    </div>
    <!--end: جدول داده ها-->




</div>

<div class="card-body">


    <!--begin: جدول داده ها-->
    <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
        id="kt_datatable" style="">
        <h1> <?php echo e(__('sentences.session_subjects')); ?></h1>
        <table class="datatable-table" style="display: block;">
            <thead class="datatable-head">
                <tr class="datatable-row" style="left: 0px;">
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.id')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.subject_title')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.subject_admin')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.subject_user')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.status')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.info')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.created_at')); ?>

                        </span>
                    </th>

                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.action')); ?>

                        </span>
                    </th>


                </tr>
            </thead>
            <tbody class="datatable-body" style="">
                <?php $__currentLoopData = $session->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="datatable-row" style="left: 0px;">
                        <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?> </span>
                        </td>
                        <td class="datatable-cell text-center"><span><?php echo e($subject->title); ?> </span>
                        </td>
                        <td class="datatable-cell text-center"><span>
                                <?php if($subject->admin_id): ?>
                                    <?php echo e($subject->admin->name); ?>

                                    <?php echo e($subject->admin->family); ?>

                                <?php endif; ?>

                            </span></td>
                        <td class="datatable-cell text-center">
                            <span>
                                <a href="<?php echo e(route('agent.profile',$subject->user->id)); ?>">
                                    <span>
                                        <?php echo e($subject->user->name); ?>

                                        <?php echo e($subject->user->family); ?>

                                    </span>
                                   </a>

                            </span>
                        </td>
                        <td class="datatable-cell text-center">
                            <span>
                                <?php switch($subject->status):
                                    case (null): ?>
                                        <?php echo e(__('sentences.in_progress')); ?>

                                    <?php break; ?>

                                    <?php case (1): ?>
                                        <?php echo e(__('sentences.confirmed')); ?>

                                    <?php break; ?>

                                    <?php case (0): ?>
                                        <?php echo e(__('sentences.failed')); ?>

                                    <?php break; ?>

                                    <?php default: ?>
                                <?php endswitch; ?>
                            </span>
                        </td>
                        <td class="datatable-cell text-center">
                            <span>
                                <?php echo e($subject->info); ?>

                            </span>
                        </td>
                        <td class="datatable-cell text-center">
                            <span><?php echo e(Morilog\Jalali\Jalalian::forge($subject->created_at)->format('Y-m-d')); ?>

                            </span>
                        </td>
                        <?php if($show_actions): ?>
                        <td class="datatable-cell text-center">
                            <?php if($subject->time): ?>
                                <span class="text  text-success">
                                    <?php echo e(__('sentences.verified')); ?>

                                </span>
                            <?php else: ?>
                                <a class="btn btn-outline-primary"
                                    href="<?php echo e(route('subject.edit', $subject->id)); ?>">
                                    <?php echo e(__('sentences.verify')); ?> </a>
                            <?php endif; ?>

                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
        </table>


    </div>
    <!--end: جدول داده ها-->



</div>



<div class="card-body">


    <!--begin: جدول داده ها-->
    <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
        id="kt_datatable" style="">
        <h1> <?php echo e(__('sentences.session_plans')); ?></h1>
        <table class="datatable-table" style="display: block;">
            <thead class="datatable-head">
                <tr class="datatable-row" style="left: 0px;">
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.id')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.plan_title')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.subject_admin')); ?>

                        </span>
                    </th>
                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.subject_user')); ?>

                        </span>
                    </th>


                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.created_at')); ?>

                        </span>
                    </th>

                    <th class="datatable-cell datatable-cell-sort text-center">
                        <span>
                            <?php echo e(__('sentences.action')); ?>

                        </span>
                    </th>


                </tr>
            </thead>
            <tbody class="datatable-body" style="">
                <?php $__currentLoopData = $session->plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="datatable-row" style="left: 0px;">
                        <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?> </span>
                        </td>
                        <td class="datatable-cell text-center"><span><?php echo e($plan->title); ?> </span>
                        </td>
                        <td class="datatable-cell text-center"><span>

                                    <?php echo e($plan->group->admin()->name); ?>

                                    <?php echo e($plan->group->admin()->family); ?>



                            </span></td>
                        <td class="datatable-cell text-center">
                            <span>

                                <a href="<?php echo e(route('agent.profile',$plan->user->id)); ?>">
                                    <span>
                                        <?php echo e($plan->user->name); ?>

                                        <?php echo e($plan->user->family); ?>

                                    </span>
                                   </a>


                            </span>
                        </td>

                        <td class="datatable-cell text-center">
                            <span><?php echo e(Morilog\Jalali\Jalalian::forge($plan->plan)->format('Y-m-d')); ?>

                            </span>
                        </td>
                        <?php if($show_actions): ?>
                        <td class="datatable-cell text-center">
                            <?php if($plan->side): ?>
                                <span class="text  text-success">
                                    <?php echo e(__('sentences.verified')); ?>

                                </span>
                            <?php else: ?>
                                <a class="btn btn-outline-primary"
                                    href="<?php echo e(route('admin.show.plan',[ $plan->id])); ?>">
                                    <?php echo e(__('sentences.verify')); ?> </a>
                            <?php endif; ?>

                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
        </table>


    </div>
    <!--end: جدول داده ها-->



</div>
<?php /**PATH G:\laravelProject\adyan\resources\views/admin/session/tables.blade.php ENDPATH**/ ?>