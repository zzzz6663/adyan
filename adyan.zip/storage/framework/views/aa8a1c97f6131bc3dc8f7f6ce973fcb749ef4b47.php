<?php $__env->startSection('main'); ?>
    <!--begin::Content-->
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class=" container ">


                <!--begin::Card-->
                <div class="card card-custom">
                    <div class="card-header flex-wrap border-0 pt-6 pb-0">
                        <div class="card-title">
                            <h3 class="card-label">
                                <?php echo e(__('sentences.session_all_table')); ?>

                                <?php echo e(__('sentences.session_all_list')); ?>

                                <span class="text-muted pt-2 font-size-sm d-block">

                                </span>
                            </h3>
                        </div>
                        <div class="card-toolbar">


                        </div>
                    </div>
                    <div class="card-body">



                        <div class="tab-pane" id="sessions" role="tabpanel">
                            <!--begin: جدول داده ها-->
                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                id="kt_datatable" style="">
                                <table class="datatable-table" style="display: block;">
                                    <thead class="datatable-head">
                                        <tr class="datatable-row" style="left: 0px;">

                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.id')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>

                                                    <?php echo e(__('sentences.session_name')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>

                                                    <?php echo e(__('sentences.session_admin')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>

                                                    <?php echo e(__('sentences.session_member')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>

                                                    <?php echo e(__('sentences.created_at')); ?>

                                                </span>
                                            </th>

                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>

                                                    <?php echo e(__('sentences.action')); ?>

                                                </span>
                                            </th>

                                        </tr>
                                    </thead>
                                    <tbody class="datatable-body" style="">
                                        <?php $__currentLoopData = $user->sessions()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usersession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="datatable-row" style="left: 0px;">
                                            <td class="datatable-cell text-center">
                                                <span><?php echo e($loop->iteration); ?> </span>
                                            </td>
                                            <td class="datatable-cell text-center">
                                                <span><?php echo e($usersession->name); ?> </span>
                                            </td>
                                            <td class="datatable-cell text-center"><span>
                                                    <?php if($usersession->user_id): ?>
                                                    <?php echo e($usersession->user->name); ?>

                                                    <?php echo e($usersession->user->family); ?>

                                                    <?php endif; ?>

                                                </span></td>
                                            <td class="datatable-cell text-center"><span>
                                                    <?php $__currentLoopData = $usersession->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($users->name); ?>

                                                    <?php echo e($users->family); ?>

                                                    <?php if($users->pivot->time): ?>
                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($users->pivot->time)->format('d-m-Y')); ?> -
                                                        <span class="text-<?php echo e($users->pivot->confirm?'success':'danger'); ?> pt-2 font-size-sm">
                                                            <?php echo e($users->pivot->confirm?__('sentences.passed'):__('sentences.unpassed')); ?>

                                                        </span>
                                                        -
                                                    <?php endif; ?>
                                                  <?php echo e($users->pivot->info); ?>

                                                    <br>
                                                    -
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </span></td>
                                            <td class="datatable-cell text-center">
                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($usersession->created_at)->format('Y-m-d')); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <a class="btn btn-outline-primary"
                                                    href="<?php echo e(route('admin.session.result', $usersession->id)); ?>">مشاهده</a>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                </table>


                            </div>
                            <!--end: جدول داده ها-->
                        </div>



                    </div>




                </div>
                <!--end::Card-->
            </div>
            <!--end::Container-->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/session/all_session.blade.php ENDPATH**/ ?>