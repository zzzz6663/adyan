<?php $__env->startSection('main'); ?>
    <!--begin::Content-->
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class=" container ">
                <div class="card card-custom">
                    <div class="card-body p-0">
                        <!--begin::ویزارد-->
                        <div class="wizard wizard-1" id="kt_wizard_v1" data-wizard-state="step-first"
                            data-wizard-clickable="false">

                            <?php echo $__env->make('sections.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                            <form class="form" action="<?php echo e(route('survey.update', $survey->id)); ?>" id="kt_form"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                                    <div class="col-xl-12 col-xxl-7">
                                        <!--begin::ویزارد Form-->
                                        <h1>
                                            <?php echo e(__('sentences.edit_survey_form')); ?>


                                        </h1>
                                        <br>
                                        <br>
                                        <!--begin::ویزارد گام 1-->
                                        <div class="row">
                                            <div class="col-xl-6">
                                                <div class="form-group fv-plugins-icon-container">
                                                    <?php echo e(__('sentences.survey_name')); ?>:
                                                    <?php echo e($survey->name); ?>

                                                    <br>
                                                    <?php echo e(__('sentences.by')); ?>:
                                                    <?php echo e($survey->user->name); ?>

                                                    <?php echo e($survey->user->family); ?>



                                                </div>
                                            </div>


                                            <div class="col-xl-6">
                                                <div class="form-group fv-plugins-icon-container">
                                                    <label>
                                                        <?php echo e(__('sentences.result')); ?>


                                                    </label>
                                                    <textarea name="info" class="form-control" id="" cols="30" rows="5"><?php echo e(old('info')); ?></textarea>
                                                    <div class="fv-plugins-message-container"></div>
                                                </div>
                                            </div>




                                        </div>
                                        <?php $__currentLoopData = $survey->curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h1><?php echo e($loop->iteration); ?>-
                                            <?php echo e($curt->title); ?></h1>
                                        <div class="row">
                                            
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.problem')); ?>:</span>
                                                <span class="content"><?php echo e($curt->problem); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.question')); ?>:</span>
                                                <span class="content"><?php echo e($curt->question); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.necessity')); ?>:</span>
                                                <span class="content"><?php echo e($curt->necessity); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.innovation')); ?>:</span>
                                                <span class="content"><?php echo e($curt->innovation); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.tags')); ?>:</span>
                                                <span class="content"><?php echo e(implode(' ',$curt->tags()->pluck('tag')->toArray())); ?></span>
                                            </div>
                                        </div>
                                        <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <?php $__currentLoopData = $survey->plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h1><?php echo e($loop->iteration); ?>-
                                            <?php echo e($plan->title); ?></h1>
                                        <div class="row">
                                            
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.en_title')); ?>:</span>
                                                <span class="content"><?php echo e($plan->en_title); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.en_tags')); ?>:</span>
                                                <span class="content">
                                                    <?php echo e(implode(explode('_',$plan->en_tags))); ?>

                                                </span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.tags')); ?>:</span>
                                                <span class="content"><?php echo e(implode(explode('_',$plan->tags))); ?></span>
                                            </div>

                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.problem')); ?>:</span>
                                                <span class="content"><?php echo e($plan->problem); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.necessity')); ?>:</span>
                                                <span class="content"><?php echo e($plan->necessity); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.question')); ?>:</span>
                                                <span class="content"><?php echo e($plan->question); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.sub_question')); ?>:</span>
                                                <span class="content"><?php echo e($plan->sub_question); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.hypo')); ?>:</span>
                                                <span class="content"><?php echo e($plan->hypo); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.theory')); ?>:</span>
                                                <span class="content"><?php echo e($plan->theory); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.structure')); ?>:</span>
                                                <span class="content"><?php echo e($plan->structure); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.method')); ?>:</span>
                                                <span class="content"><?php echo e($plan->method); ?></span>
                                            </div>
                                            <div class="col-lg-3">
                                                <span class="title"> <?php echo e(__('sentences.source')); ?>:</span>
                                                <span class="content"><?php echo e($plan->source); ?></span>
                                            </div>

                                            
                                        </div>
                                        <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <!--begin::ویزارد اقدامات-->
                                        <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                            
                                            <div>
                                                <input type="submit" value="            <?php echo e(__('sentences.save')); ?>   "
                                                    class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                                <a class="btn btn-danger font-weight-bold text-uppercase px-9 py-4"
                                                    href="<?php echo e(route('survey.index')); ?>"> <?php echo e(__('sentences.back')); ?></a>


                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--end::ویزارد اقدامات-->
                            </form>


                            <!--end::ویزارد Form-->
                        </div>
                    </div>
                    <!--end::ویزارد Body-->
                </div>
                <!--end::ویزارد-->
            </div>
            <!--end::ویزارد-->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/survey/edit.blade.php ENDPATH**/ ?>