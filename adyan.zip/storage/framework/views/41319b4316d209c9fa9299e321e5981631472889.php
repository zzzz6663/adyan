<?php $__env->startSection('main'); ?>
<!--begin::Content-->
 <?php echo $__env->make('admin.agent.profile_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/agent/profile.blade.php ENDPATH**/ ?>