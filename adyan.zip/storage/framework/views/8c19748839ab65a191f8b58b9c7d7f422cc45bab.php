<?php ($side=true); ?>
<?php $__env->startSection('main'); ?>
<div id="kt_header_mobile" class="header-mobile ">
    <!--begin::Logo-->
    <a href="index.html">
        <img alt="Logo" src="assets/media/logos/logo-letter-1.png" class="logo-default max-h-30px">
    </a>
    <!--end::Logo-->

    <!--begin::Toolbar-->
    <div class="d-flex align-items-center">

        <button class="btn p-0 burger-icon burger-icon-left ml-4" id="kt_header_mobile_toggle">
            <span></span>
        </button>

        <button class="btn btn-icon btn-hover-transparent-white p-0 ml-3" id="kt_header_mobile_topbar_toggle">
            <span class="svg-icon svg-icon-xl">
                <!--begin::Svg Icon | path:assets/media/svg/icons/عمومی/User.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <polygon points="0 0 24 0 24 24 0 24"></polygon>
                        <path d="M12,11 C9.790861,11 8,9.209139 8,7 C8,4.790861 9.790861,3 12,3 C14.209139,3 16,4.790861 16,7 C16,9.209139 14.209139,11 12,11 Z" fill="#000000" fill-rule="nonzero" opacity="0.3"></path>
                        <path d="M3.00065168,20.1992055 C3.38825852,15.4265159 7.26191235,13 11.9833413,13 C16.7712164,13 20.7048837,15.2931929 20.9979143,20.2 C21.0095879,20.3954741 20.9979143,21 20.2466999,21 C16.541124,21 11.0347247,21 3.72750223,21 C3.47671215,21 2.97953825,20.45918 3.00065168,20.1992055 Z" fill="#000000" fill-rule="nonzero"></path>
                    </g>
                </svg>
                <!--end::Svg Icon--></span> </button>
    </div>
    <!--end::Toolbar-->
</div>

<div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="d-flex flex-row flex-column-fluid page">
        <!--begin::Wrapper-->
        <div class="d-flex flex-column flex-row-fluid wrapper" id="kt_wrapper">
            <!--begin::Header-->
            <div id="kt_header" class="header  header-fixed " style="background:rgb(197, 197, 197)">
                <!--begin::Container-->
                <div class=" container  d-flex align-items-stretch justify-content-between">
                    <!--begin::راست-->
                    <div class="d-flex align-items-stretch mr-3">
                        <!--begin::Header Logo-->
                        <div class="header-logo">
                            <a href="index.html">
                                <img alt="Logo" src="assets/media/logos/logo-letter-9.png" class="logo-default max-h-40px">
                                <img alt="Logo" src="assets/media/logos/logo-letter-1.png" class="logo-sticky max-h-40px">
                            </a>
                        </div>
                        <!--end::Header Logo-->

                        <!--begin::Header Menu Wrapper-->
                        <div class="header-menu-wrapper header-menu-wrapper-left" id="kt_header_menu_wrapper">
                            <!--begin::Header Menu-->
                            <div id="kt_header_menu" class="header-menu header-menu-left header-menu-mobile  header-menu-layout-default ">
                                <!--begin::Header Nav-->
                                <ul class="menu-nav ">
                                    <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="click" aria-haspopup="true"><a href="javascript:;" class="menu-link menu-toggle"><span class="menu-text">داشبورد</span><i class="menu-arrow"></i></a>
                                        <div class="menu-submenu menu-submenu-classic menu-submenu-left">
                                            <ul class="menu-subnav">
                                                <li class="menu-item " aria-haspopup="true"><a href="index.html" class="menu-link "><span class="menu-text">آخرین آپدیت</span><span class="menu-desc"></span></a></li>
                                                <li class="menu-item " aria-haspopup="true"><a target="_blank" href="https://preview.keenthemes.com/metronic/preview/demo2/builder.html" class="menu-link "><span class="menu-text">چیدمان سازنده</span><span class="menu-desc"></span></a></li>
                                            </ul>
                                        </div>
                                    </li>

                                </ul>
                                <!--end::Header Nav-->
                            </div>
                            <!--end::Header Menu-->
                        </div>
                        <!--end::Header Menu Wrapper-->
                    </div>
                    <!--end::راست-->

                    <!--begin::Topbar-->
                    <div class="topbar">


                        <!--begin::User-->
                        <div class="dropdown">
                            <!--begin::Toggle-->
                            <div class="topbar-item" data-toggle="dropdown" data-offset="0px,0px">
                                <div class="btn btn-icon btn-hover-transparent-white d-flex align-items-center btn-lg px-md-2 w-md-auto">
                                    <span class="text-white opacity-70 font-weight-bold font-size-base d-none d-md-inline mr-1">سلام,</span>
                                    <span class="text-white opacity-90 font-weight-bolder font-size-base d-none d-md-inline mr-4">


                                    </span>
                                </div>
                            </div>
                            <!--end::Toggle-->

                            <!--begin::دراپ دان-->
                            <div class="dropdown-menu p-0 m-0 dropdown-menu-right dropdown-menu-anim-up dropdown-menu-lg p-0">
                                <!--begin::Header-->
                                <div class="d-flex align-items-center p-8 rounded-top">
                                    <!--begin::سیمبل-->
                                    <div class="symbol symbol-md bg-light-primary mr-3 flex-shrink-0">
                                        <img src="assets/media/users/300_21.jpg" alt="">
                                    </div>
                                    <!--end::سیمبل-->

                                    <!--begin::متن-->
                                    <div class="text-dark m-0 flex-grow-1 mr-3 font-size-h5">محسن</div>
                                    <span class="label label-light-success label-lg font-weight-bold label-inline">3 پبام</span>
                                    <!--end::متن-->
                                </div>
                                <div class="separator separator-solid"></div>
                                <!--end::Header-->

                                <!--begin::Nav-->
                                <div class="navi navi-spacer-x-0 pt-5">
                                    <!--begin::Item-->
                                    <a href="custom/apps/user/profile-1/personal-information.html" class="navi-item px-8">
                                        <div class="navi-link">
                                            <div class="navi-icon mr-2">
                                                <i class="flaticon2-calendar-3 text-success"></i>
                                            </div>
                                            <div class="navi-text">
                                                <div class="font-weight-bold">
                                                    پروفایل من
                                                </div>
                                                <div class="text-muted">
                                                    تنظیمات اکانت
                                                    <span class="label label-light-danger label-inline font-weight-bold">بروزرسانی</span>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <!--end::Item-->

                                    <!--begin::Item-->
                                    <a href="custom/apps/user/profile-3.html" class="navi-item px-8">
                                        <div class="navi-link">
                                            <div class="navi-icon mr-2">
                                                <i class="flaticon2-mail text-warning"></i>
                                            </div>
                                            <div class="navi-text">
                                                <div class="font-weight-bold">
                                                    پیام های من
                                                </div>
                                                <div class="text-muted">
                                                    صندوق پیام ها و کارها
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <!--end::Item-->

                                    <!--begin::Item-->
                                    <a href="custom/apps/user/profile-2.html" class="navi-item px-8">
                                        <div class="navi-link">
                                            <div class="navi-icon mr-2">
                                                <i class="flaticon2-rocket-1 text-danger"></i>
                                            </div>
                                            <div class="navi-text">
                                                <div class="font-weight-bold">
                                                    فعالیت های من
                                                </div>
                                                <div class="text-muted">
                                                    لاگ ها و اعلان ها
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <!--end::Item-->

                                    <!--begin::Item-->
                                    <a href="custom/apps/userprofile-1/overview.html" class="navi-item px-8">
                                        <div class="navi-link">
                                            <div class="navi-icon mr-2">
                                                <i class="flaticon2-hourglass text-primary"></i>
                                            </div>
                                            <div class="navi-text">
                                                <div class="font-weight-bold">
                                                    کارهای من
                                                </div>
                                                <div class="text-muted">
                                                    اخرین کارها و پروژه ها
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                    <!--end::Item-->

                                    <!--begin::Footer-->
                                    <div class="navi-separator mt-3"></div>
                                    <div class="navi-footer  px-8 py-5">
                                        <a href="custom/user/login-v2.html" target="_blank" class="btn btn-light-primary font-weight-bold">خروج</a>
                                        <a href="custom/user/login-v2.html" target="_blank" class="btn btn-clean font-weight-bold">ارتقا پلن</a>
                                    </div>
                                    <!--end::Footer-->
                                </div>
                                <!--end::Nav-->
                            </div>
                            <!--end::دراپ دان-->
                        </div>
                        <!--end::User-->
                    </div>
                    <!--end::Topbar-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::Header-->

            <!--begin::Content-->
            <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">


                <!--begin::Entry-->
                <div class="d-flex flex-column-fluid">
                    <!--begin::Container-->
                    <div class=" container ">
                        <!--begin::Card-->
                        <div class="card card-custom gutter-b">
                            <!--begin::Body-->
                            <div class="card-body p-0">
                                <!--begin::ویزارد-->
                                <div class="wizard wizard-1" id="kt_contact_add" data-wizard-state="first" data-wizard-clickable="true">
                                    <div class="kt-grid__item">
                                        <!--begin::ویزارد Nav-->
                                        <div class="wizard-nav border-bottom">
                                            <div class="wizard-steps p-8 p-lg-10">
                                                <div class="wizard-step" data-wizard-type="step" data-wizard-state="current">
                                                    <div class="wizard-label">
                                                        <span class="svg-icon svg-icon-4x wizard-icon">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/ارتباطات/چت-check.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path d="M4.875,20.75 C4.63541667,20.75 4.39583333,20.6541667 4.20416667,20.4625 L2.2875,18.5458333 C1.90416667,18.1625 1.90416667,17.5875 2.2875,17.2041667 C2.67083333,16.8208333 3.29375,16.8208333 3.62916667,17.2041667 L4.875,18.45 L8.0375,15.2875 C8.42083333,14.9041667 8.99583333,14.9041667 9.37916667,15.2875 C9.7625,15.6708333 9.7625,16.2458333 9.37916667,16.6291667 L5.54583333,20.4625 C5.35416667,20.6541667 5.11458333,20.75 4.875,20.75 Z" fill="#000000" fill-rule="nonzero" opacity="0.3"></path>
                                                                    <path d="M2,11.8650466 L2,6 C2,4.34314575 3.34314575,3 5,3 L19,3 C20.6568542,3 22,4.34314575 22,6 L22,15 C22,15.0032706 21.9999948,15.0065399 21.9999843,15.009808 L22.0249378,15 L22.0249378,19.5857864 C22.0249378,20.1380712 21.5772226,20.5857864 21.0249378,20.5857864 C20.7597213,20.5857864 20.5053674,20.4804296 20.317831,20.2928932 L18.0249378,18 L12.9835977,18 C12.7263047,14.0909841 9.47412135,11 5.5,11 C4.23590829,11 3.04485894,11.3127315 2,11.8650466 Z M6,7 C5.44771525,7 5,7.44771525 5,8 C5,8.55228475 5.44771525,9 6,9 L15,9 C15.5522847,9 16,8.55228475 16,8 C16,7.44771525 15.5522847,7 15,7 L6,7 Z" fill="#000000"></path>
                                                                </g>

                                                            </svg>
                                                            <!--end::Svg Icon--></span>
                                                        <h3 class="wizard-title">1. اطلاعات شخصی</h3>
                                                    </div>
                                                    <span class="svg-icon svg-icon-xl wizard-arrow">
                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <polygon points="0 0 24 0 24 24 0 24"/>
                                                                <rect fill="#000000" opacity="0.3" transform="translate(15.000000, 12.000000) scale(-1, 1) rotate(-90.000000) translate(-15.000000, -12.000000) " x="14" y="7" width="2" height="10" rx="1"/>
                                                                <path d="M3.7071045,15.7071045 C3.3165802,16.0976288 2.68341522,16.0976288 2.29289093,15.7071045 C1.90236664,15.3165802 1.90236664,14.6834152 2.29289093,14.2928909 L8.29289093,8.29289093 C8.67146987,7.914312 9.28105631,7.90106637 9.67572234,8.26284357 L15.6757223,13.7628436 C16.0828413,14.136036 16.1103443,14.7686034 15.7371519,15.1757223 C15.3639594,15.5828413 14.7313921,15.6103443 14.3242731,15.2371519 L9.03007346,10.3841355 L3.7071045,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(9.000001, 11.999997) scale(-1, -1) rotate(90.000000) translate(-9.000001, -11.999997) "/>
                                                            </g>
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="wizard-step" data-wizard-type="step" data-wizard-state="pending">
                                                    <div class="wizard-label">
                                                        <span class="svg-icon svg-icon-4x wizard-icon">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/Devices/Display1.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path d="M11,20 L11,17 C11,16.4477153 11.4477153,16 12,16 C12.5522847,16 13,16.4477153 13,17 L13,20 L15.5,20 C15.7761424,20 16,20.2238576 16,20.5 C16,20.7761424 15.7761424,21 15.5,21 L8.5,21 C8.22385763,21 8,20.7761424 8,20.5 C8,20.2238576 8.22385763,20 8.5,20 L11,20 Z" fill="#000000" opacity="0.3"></path>
                                                                    <path d="M3,5 L21,5 C21.5522847,5 22,5.44771525 22,6 L22,16 C22,16.5522847 21.5522847,17 21,17 L3,17 C2.44771525,17 2,16.5522847 2,16 L2,6 C2,5.44771525 2.44771525,5 3,5 Z M4.5,8 C4.22385763,8 4,8.22385763 4,8.5 C4,8.77614237 4.22385763,9 4.5,9 L13.5,9 C13.7761424,9 14,8.77614237 14,8.5 C14,8.22385763 13.7761424,8 13.5,8 L4.5,8 Z M4.5,10 C4.22385763,10 4,10.2238576 4,10.5 C4,10.7761424 4.22385763,11 4.5,11 L7.5,11 C7.77614237,11 8,10.7761424 8,10.5 C8,10.2238576 7.77614237,10 7.5,10 L4.5,10 Z" fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon--></span>
                                                        <h3 class="wizard-title">2. تنظیمات اکانت</h3>
                                                    </div>
                                                    <span class="svg-icon svg-icon-xl wizard-arrow">
                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <polygon points="0 0 24 0 24 24 0 24"/>
                                                                <rect fill="#000000" opacity="0.3" transform="translate(15.000000, 12.000000) scale(-1, 1) rotate(-90.000000) translate(-15.000000, -12.000000) " x="14" y="7" width="2" height="10" rx="1"/>
                                                                <path d="M3.7071045,15.7071045 C3.3165802,16.0976288 2.68341522,16.0976288 2.29289093,15.7071045 C1.90236664,15.3165802 1.90236664,14.6834152 2.29289093,14.2928909 L8.29289093,8.29289093 C8.67146987,7.914312 9.28105631,7.90106637 9.67572234,8.26284357 L15.6757223,13.7628436 C16.0828413,14.136036 16.1103443,14.7686034 15.7371519,15.1757223 C15.3639594,15.5828413 14.7313921,15.6103443 14.3242731,15.2371519 L9.03007346,10.3841355 L3.7071045,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(9.000001, 11.999997) scale(-1, -1) rotate(90.000000) translate(-9.000001, -11.999997) "/>
                                                            </g>
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="wizard-step" data-wizard-type="step" data-wizard-state="pending">
                                                    <div class="wizard-label">
                                                        <span class="svg-icon svg-icon-4x wizard-icon">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/خانه/Globe.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path d="M13,18.9450712 L13,20 L14,20 C15.1045695,20 16,20.8954305 16,22 L8,22 C8,20.8954305 8.8954305,20 10,20 L11,20 L11,18.9448245 C9.02872877,18.7261967 7.20827378,17.866394 5.79372555,16.5182701 L4.73856106,17.6741866 C4.36621808,18.0820826 3.73370941,18.110904 3.32581341,17.7385611 C2.9179174,17.3662181 2.88909597,16.7337094 3.26143894,16.3258134 L5.04940685,14.367122 C5.46150313,13.9156769 6.17860937,13.9363085 6.56406875,14.4106998 C7.88623094,16.037907 9.86320756,17 12,17 C15.8659932,17 19,13.8659932 19,10 C19,7.73468744 17.9175842,5.65198725 16.1214335,4.34123851 C15.6753081,4.01567657 15.5775721,3.39010038 15.903134,2.94397499 C16.228696,2.49784959 16.8542722,2.4001136 17.3003976,2.72567554 C19.6071362,4.40902808 21,7.08906798 21,10 C21,14.6325537 17.4999505,18.4476269 13,18.9450712 Z" fill="#000000" fill-rule="nonzero"></path>
                                                                    <circle fill="#000000" opacity="0.3" cx="12" cy="10" r="6"></circle>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon--></span>
                                                        <h3 class="wizard-title">3. نشانی جزئیات</h3>
                                                    </div>
                                                    <span class="svg-icon svg-icon-xl wizard-arrow">
                                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <polygon points="0 0 24 0 24 24 0 24"/>
                                                                <rect fill="#000000" opacity="0.3" transform="translate(15.000000, 12.000000) scale(-1, 1) rotate(-90.000000) translate(-15.000000, -12.000000) " x="14" y="7" width="2" height="10" rx="1"/>
                                                                <path d="M3.7071045,15.7071045 C3.3165802,16.0976288 2.68341522,16.0976288 2.29289093,15.7071045 C1.90236664,15.3165802 1.90236664,14.6834152 2.29289093,14.2928909 L8.29289093,8.29289093 C8.67146987,7.914312 9.28105631,7.90106637 9.67572234,8.26284357 L15.6757223,13.7628436 C16.0828413,14.136036 16.1103443,14.7686034 15.7371519,15.1757223 C15.3639594,15.5828413 14.7313921,15.6103443 14.3242731,15.2371519 L9.03007346,10.3841355 L3.7071045,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(9.000001, 11.999997) scale(-1, -1) rotate(90.000000) translate(-9.000001, -11.999997) "/>
                                                            </g>
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="wizard-step" data-wizard-type="step" data-wizard-state="pending">
                                                    <div class="wizard-label">
                                                        <span class="svg-icon svg-icon-4x wizard-icon">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/general/اطلاع2.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path d="M13.2070325,4 C13.0721672,4.47683179 13,4.97998812 13,5.5 C13,8.53756612 15.4624339,11 18.5,11 C19.0200119,11 19.5231682,10.9278328 20,10.7929675 L20,17 C20,18.6568542 18.6568542,20 17,20 L7,20 C5.34314575,20 4,18.6568542 4,17 L4,7 C4,5.34314575 5.34314575,4 7,4 L13.2070325,4 Z" fill="#000000"></path>
                                                                    <circle fill="#000000" opacity="0.3" cx="18.5" cy="5.5" r="2.5"></circle>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon--></span>
                                                        <h3 class="wizard-title">4. بررسی و ارسال کنید</h3>
                                                    </div>
                                                    <span class="svg-icon svg-icon-xl wizard-arrow last">
                                                        <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Arrow-right.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <polygon points="0 0 24 0 24 24 0 24"></polygon>
                                                                <rect fill="#000000" opacity="0.3" transform="translate(12.000000, 12.000000) rotate(-90.000000) translate(-12.000000, -12.000000) " x="11" y="5" width="2" height="14" rx="1"></rect>
                                                                <path d="M9.70710318,15.7071045 C9.31657888,16.0976288 8.68341391,16.0976288 8.29288961,15.7071045 C7.90236532,15.3165802 7.90236532,14.6834152 8.29288961,14.2928909 L14.2928896,8.29289093 C14.6714686,7.914312 15.281055,7.90106637 15.675721,8.26284357 L21.675721,13.7628436 C22.08284,14.136036 22.1103429,14.7686034 21.7371505,15.1757223 C21.3639581,15.5828413 20.7313908,15.6103443 20.3242718,15.2371519 L15.0300721,10.3841355 L9.70710318,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(14.999999, 11.999997) scale(1, -1) rotate(90.000000) translate(-14.999999, -11.999997) "></path>
                                                            </g>
                                                        </svg>
                                                        <!--end::Svg Icon--></span>
                                                </div>
                                            </div>
                                        </div>
                                        <!--end::ویزارد Nav-->
                                    </div>
                                    <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                                        <div class="col-xl-12 col-xxl-7">
                                            <!--begin::Form ویزارد Form-->
                                            <form  action="<?php echo e(route('home.index')); ?>" method="GET"    >
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('get'); ?>
                                                <!--begin::Form ویزارد گام 1-->
                                                <div class="pb-5" data-wizard-type="step-content" data-wizard-state="current">
                                                    <h3 class="mb-10 font-weight-bold text-dark">    اطلاعات اولیه :</h3>
                                                    <div class="row">
                                                        <div class="col-xl-12">
                                                            <?php if(!request('code')): ?>


                                                            <div class="form-group row fv-plugins-icon-container">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">کد دانشجویی </label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <input class="form-control form-control-lg form-control-solid" name="code" type="number" >
                                                                    <div class="fv-plugins-message-container"></div>
                                                                </div>
                                                            </div>
                                                            <?php else: ?>
                                                            <div class="form-group row">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">آواتار</label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <div class="image-input image-input-outline" id="kt_مخاطب_add_avatar">
                                                                        <div class="image-input-wrapper" style="background-image: url(assets/media/users/100_2.jpg)"></div>

                                                                        <label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="تغییر آواتار">
                                                                            <i class="fa fa-pen icon-sm text-muted"></i>
                                                                            <input type="file" name="profile_avatar" accept=".png, .jpg, .jpeg">
                                                                            <input type="hidden" name="profile_avatar_remove">
                                                                        </label>

                                                                        <span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="" data-original-title="لغو avatar">
                                                                            <i class="ki ki-bold-close icon-xs text-muted"></i>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row fv-plugins-icon-container">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">نام</label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <input class="form-control form-control-lg form-control-solid" name="firstname" type="text" value="آنا">
                                                                    <div class="fv-plugins-message-container"></div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row fv-plugins-icon-container">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">نام خانوادگی</label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <input class="form-control form-control-lg form-control-solid" name="lastname" type="text" value="کیوانی">
                                                                    <div class="fv-plugins-message-container"></div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">نام شرکت</label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <input class="form-control form-control-lg form-control-solid" name="شرکتname" type="text" value="لوپ">
                                                                    <span class="form-text text-muted">اگر می خواهید فاکتورهای خود را به یک شرکت بفرستید. خالی بگذارید تا از نام کامل خود استفاده کنید.</span>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row fv-plugins-icon-container">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">مخاطب تلفن</label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <div class="input-group input-group-lg input-group-solid">
                                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="la la-phone"></i></span></div>
                                                                        <input type="text" class="form-control form-control-lg form-control-solid" name="phone" value="4567896745" placeholder="تلفن">
                                                                    </div>
                                                                    <span class="form-text text-muted">ما هرگز ایمیل شما را با هیچ کس دیگری به اشتراک نمی گذاریم.</span>
                                                                    <div class="fv-plugins-message-container"></div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row fv-plugins-icon-container">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">نشانی پست الکترونیکی</label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <div class="input-group input-group-lg input-group-solid">
                                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="la la-at"></i></span></div>
                                                                        <input type="text" class="form-control form-control-lg form-control-solid" name="email" value="anna.krox@loop.com" placeholder="پست الکترونیک">
                                                                    </div>
                                                                    <div class="fv-plugins-message-container"></div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row">
                                                                <label class="col-xl-3 col-lg-3 col-form-label">سایت شرکت</label>
                                                                <div class="col-lg-9 col-xl-9">
                                                                    <div class="input-group input-group-lg input-group-solid">
                                                                        <input type="text" class="form-control form-control-lg form-control-solid" name="شرکتwebsite" placeholder="loop" value="لوپ">
                                                                        <div class="input-group-append"><span class="input-group-text">.com</span></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--end::Form ویزارد گام 1-->


                                                <!--begin::ویزارد اقدامات-->
                                                <div class="d-flex justify-content-between border-top pt-10">
                                                    <div class="mr-2">
                                                        <button type="button" class="btn btn-light-primary font-weight-bold text-uppercase px-9 py-4" data-wizard-type="action-prev">
                                                            قبلی
                                                        </button>
                                                    </div>
                                                    <div>
                                                        <button type="button" class="btn btn-success font-weight-bold text-uppercase px-9 py-4" data-wizard-type="action-submit">
                                                            ارسال
                                                        </button>
                                                        <button class="btn btn-primary font-weight-bold text-uppercase px-9 py-4" >
                                                            گام بعد
                                                        </button>
                                                    </div>
                                                </div>
                                                <!--end::ویزارد اقدامات-->
                                                <div></div>
                                                <div></div>
                                                <div></div>
                                            </form>
                                            <!--end::Form ویزارد Form-->
                                        </div>
                                    </div>
                                </div>
                                <!--end::ویزارد-->
                            </div>
                            <!--end::Body-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <!--end::Container-->
                </div>
                <!--end::Entry-->
            </div>
            <!--end::Content-->

        </div>
        <!--end::Wrapper-->
    </div>
    <!--end::Page-->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/home/register.blade.php ENDPATH**/ ?>