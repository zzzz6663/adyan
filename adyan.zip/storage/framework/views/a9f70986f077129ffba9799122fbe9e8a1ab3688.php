<?php $__env->startSection('main'); ?>
    <!--begin::Content-->
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class=" container ">


                <div class="row">
                    <div class="col-lg-12 order-1 order-xxl-2">
                        <div class="card card-custom card-stretch gutter-b">
                            <!--begin::Header-->
                            <div class="card-header border-0">
                                <h3 class="card-title font-weight-bolder text-dark">
                                    <?php echo e(__('sentences.notes')); ?>



                                </h3>

                            </div>
                            <!--end::Header-->

                            <!--begin::Body-->
                            <div class="card-body pt-0">
                                <ul>
                                    <li>
                                        <?php echo e(__('sentences.note6')); ?>

                                    </li>
                                    <li>  <?php echo e(__('sentences.note7')); ?> </li>
                                    <li>  <?php echo e(__('sentences.note8')); ?>  </li>
                                    <li>   <?php echo e(__('sentences.note9')); ?> </li>
                                    <li>   <?php echo e(__('sentences.note10')); ?> </li>
                                </ul>



                            </div>
                            <!--end::Body-->

                            <div class="card-body">


                                     <!--begin: جدول داده ها-->
                                     <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                     id="kt_datatable" style="">
                                     <h1> <?php echo e(__('sentences.session_subjects')); ?></h1>
                                     <table class="datatable-table" style="display: block;">
                                         <thead class="datatable-head">
                                             <tr class="datatable-row" style="left: 0px;">
                                                 <th class="datatable-cell datatable-cell-sort text-center">
                                                     <span>
                                                         <?php echo e(__('sentences.id')); ?>

                                                     </span>
                                                 </th>
                                                 <th class="datatable-cell datatable-cell-sort text-center">
                                                     <span>
                                                         <?php echo e(__('sentences.subject_title')); ?>

                                                     </span>
                                                 </th>
                                                 <th class="datatable-cell datatable-cell-sort text-center">
                                                     <span>
                                                         <?php echo e(__('sentences.subject_admin')); ?>

                                                     </span>
                                                 </th>

                                                 <th class="datatable-cell datatable-cell-sort text-center">
                                                     <span>
                                                         <?php echo e(__('sentences.info')); ?>

                                                     </span>
                                                 </th>

                                                 <th class="datatable-cell datatable-cell-sort text-center">
                                                     <span>
                                                         <?php echo e(__('sentences.action')); ?>

                                                     </span>
                                                 </th>


                                             </tr>
                                         </thead>
                                         <tbody class="datatable-body" style="">
                                             <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <tr class="datatable-row" style="left: 0px;">
                                                     <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?> </span>
                                                     </td>
                                                     <td class="datatable-cell text-center"><span><?php echo e($subject->title); ?> </span>
                                                     </td>
                                                     <td class="datatable-cell text-center"><span>
                                                             <?php if($subject->admin_id): ?>
                                                                 <?php echo e($subject->admin->name); ?>

                                                                 <?php echo e($subject->admin->family); ?>

                                                             <?php endif; ?>

                                                         </span></td>


                                                     <td class="datatable-cell text-center">
                                                         <span>
                                                             <?php echo e($subject->info); ?>

                                                         </span>
                                                     </td>
                                                 
                                                     <td class="datatable-cell text-center">
                                                         <?php if($subject->time): ?>
                                                             <span class="text  text-success">
                                                                 <?php echo e(__('sentences.verified')); ?>

                                                             </span>
                                                         <?php else: ?>
                                                             <a class="btn btn-outline-primary"
                                                                 href="<?php echo e(route('subject.edit', $subject->id)); ?>">
                                                                 <?php echo e(__('sentences.verify')); ?> </a>
                                                         <?php endif; ?>

                                                     </td>
                                                 </tr>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                         </tbody>
                                     </table>


                                 </div>
                                 <!--end: جدول داده ها-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Container-->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/student/select_curt.blade.php ENDPATH**/ ?>