<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <div class="card-body p-0">
                    <!--begin::ویزارد-->
                    <div class="wizard wizard-1" id="kt_wizard_v1" data-wizard-state="step-first"
                        data-wizard-clickable="false">

                        <?php echo $__env->make('sections.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <form class="form" action="<?php echo e(route('group.store')); ?>" id="kt_form"
                            method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                                <div class="col-xl-12 col-xxl-7">
                                    <!--begin::ویزارد Form-->
                                        <h1>
                                            <?php echo e(__('sentences.new_group_form')); ?>


                                        </h1>
                                            <br>
                                            <br>
                                    <!--begin::ویزارد گام 1-->
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>  <?php echo e(__('sentences.group_name')); ?>  </label>
                                                <input type="text" value="<?php echo e(old('name')); ?>" class="form-control" name="name"
                                                    placeholder="   <?php echo e(__('sentences.group_name')); ?> " >
                                                <span class="form-text text-muted">
                                                    <?php echo e(__('sentences.enter_group_name')); ?>

                                                </span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>
                                                    <?php echo e(__('sentences.enter_master_group_name')); ?>


                                                </label>
                                                <select name="user_id"  class="form-control  ">
                                                    <option value="">   <?php echo e(__('sentences.select_one')); ?> </option>
                                                    <?php $__currentLoopData = App\Models\User::where('level','master')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option <?php echo e(old('user_id',[])==$master->id?'selected':''); ?> value="<?php echo e($master->id); ?>"><?php echo e($master->name); ?> <?php echo e($master->family); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>



                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>

                                                    <?php echo e(__('sentences.select_master')); ?>

                                                </label>
                                                <select name="masters[]"   multiple class="form-control  select2">
                                                    <option value="">          <?php echo e(__('sentences.select_one')); ?> </option>
                                                    <?php $__currentLoopData = App\Models\User::where('level','master')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option <?php echo e(in_array($master->id ,old('masters',[]))?'selected':''); ?> value="<?php echo e($master->id); ?>"><?php echo e($master->name); ?> <?php echo e($master->family); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>


                                    </div>


                                    <!--begin::ویزارد اقدامات-->
                                    <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                        
                                        <div>
                                            <input type="submit" value="            <?php echo e(__('sentences.save')); ?>   "
                                                class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                                <a class="btn btn-danger font-weight-bold text-uppercase px-9 py-4" href="<?php echo e(route('group.index')); ?>">          <?php echo e(__('sentences.back')); ?></a>


                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--end::ویزارد اقدامات-->
                        </form>


                        <!--end::ویزارد Form-->
                    </div>
                </div>
                <!--end::ویزارد Body-->
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/group/create.blade.php ENDPATH**/ ?>