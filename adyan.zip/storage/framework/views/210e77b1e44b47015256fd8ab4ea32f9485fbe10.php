<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <div class="card-body p-0">
                    <!--begin::ویزارد-->
                    <div class="wizard wizard-1" id="kt_wizard_v1" data-wizard-state="step-first"
                        data-wizard-clickable="false">

                        <?php echo $__env->make('sections.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <form class="form" action="<?php echo e(route('quiz.question.update',[$quiz->id,$question->id])); ?>" id="kt_form"
                            method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                                <div class="col-xl-12 col-xxl-7">
                                    <!--begin::ویزارد Form-->
                                        <h1>
                                            فرم ویرایش  سوال
                                        </h1>
                                            <br>
                                            <br>
                                    <!--begin::ویزارد گام 1-->
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>    متن سوال   </label>
                                                <input type="text" value="<?php echo e(old('question',$question->question)); ?>" class="form-control" name="question"
                                                    placeholder="  عنوان " >
                                                <span class="form-text text-muted">لطفا   سوال     را وارد
                                                    کنید.</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>      جواب یک    </label>
                                                <input type="text" value="<?php echo e(old('a1',$question->a1)); ?>" class="form-control" name="a1"
                                                    placeholder="  عنوان " >
                                                <span class="form-text text-muted">
                                                    متن جواب یک را وارد کنید
                                                     .</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>      جواب دو    </label>
                                                <input type="text" value="<?php echo e(old('a2',$question->a2)); ?>" class="form-control" name="a2"
                                                    placeholder="  عنوان " >
                                                <span class="form-text text-muted">
                                                    متن جواب دو را وارد کنید
                                                     .</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>      جواب سه     </label>
                                                <input type="text" value="<?php echo e(old('a3',$question->a3)); ?>" class="form-control" name="a3"
                                                    placeholder="  عنوان " >
                                                <span class="form-text text-muted">
                                                    متن جواب سه  را وارد کنید
                                                     .</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>      جواب چهار    </label>
                                                <input type="text" value="<?php echo e(old('a4',$question->a4)); ?>" class="form-control" name="a4"
                                                    placeholder="  عنوان " >
                                                <span class="form-text text-muted">
                                                    متن جواب چهار را وارد کنید
                                                     .</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>         جواب سوال    </label>
                                                <select name="answer" id="" class="form-control">
                                                    <option value="">یک مورد را انتخاب کنید </option>
                                                    <option  <?php echo e(old('answer',$question->answer)=='a1'?'selected':''); ?> value="a1">گزینه یک</option>
                                                    <option  <?php echo e(old('answer',$question->answer)=='a2'?'selected':''); ?> value="a2">گزینه دو</option>
                                                    <option  <?php echo e(old('answer',$question->answer)=='a3'?'selected':''); ?> value="a3">گزینه سه</option>
                                                    <option  <?php echo e(old('answer',$question->answer)=='a4'?'selected':''); ?> value="a4">گزینه چهار</option>
                                                </select>
                                            </div>
                                        </div>





                                    </div>


                                    <!--begin::ویزارد اقدامات-->
                                    <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                        
                                        <div>
                                            <input type="submit" value="  دخیره   "
                                                class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                                <a class="btn btn-danger font-weight-bold text-uppercase px-9 py-4" href="<?php echo e(route('quiz.question.index',$quiz->id)); ?>">برکشت</a>


                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--end::ویزارد اقدامات-->
                        </form>


                        <!--end::ویزارد Form-->
                    </div>
                </div>
                <!--end::ویزارد Body-->
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/quiz/question/edit.blade.php ENDPATH**/ ?>