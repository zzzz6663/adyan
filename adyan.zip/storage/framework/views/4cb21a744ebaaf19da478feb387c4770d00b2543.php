<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">


            <!--begin::Card-->
            <div class="card card-custom">
                <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title">
                        <h3 class="card-label">
                            <?php echo e(__('sentences.users_table')); ?>

                             <span class="text-muted pt-2 font-size-sm d-block">
                                <?php echo e(__('sentences.statement_list')); ?>

                            </span>
                        </h3>
                    </div>

                </div>
                <div class="card-body">
                    <!--begin: جستجو Form-->
                    <!--begin::جستجو Form-->
                    <form action="<?php echo e(route('agent.masters')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('get'); ?>
                    

                </form>
                    <!--end::جستجو Form-->
                    <!--end: جستجو Form-->

                    <!--begin: جدول داده ها-->
                    <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                        id="kt_datatable" style="">
                        <table class="datatable-table" >
                            <thead class="datatable-head">
                                <tr class="datatable-row" style="left: 0px;">

                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.id')); ?>

                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.student')); ?>

                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.title')); ?>

                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.guid')); ?>

                                        </span>
                                    </th>


                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.master_guid')); ?>

                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.group')); ?>

                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.created_at')); ?>

                                        </span>
                                    </th>


                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            <?php echo e(__('sentences.action')); ?>

                                        </span>
                                    </th>

                                </tr>
                            </thead>
                            <tbody class="datatable-body" style="">
                                <?php $__currentLoopData = $curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="datatable-row" style="left: 0px;">
                                    <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?> </span></td>
                                    <td class="datatable-cell text-center"><span>
                                        <?php echo e($curt->user->name); ?>

                                        <?php echo e($curt->user->family); ?>

                                    </span></td>

                                    <td class="datatable-cell text-center"><span><?php echo e($curt->title); ?> </span></td>
                                    <td class="datatable-cell text-center"><span>

                                    <?php if($curt->master_id): ?>
                                    <?php echo e($curt->master()->name); ?>

                                    <?php echo e($curt->master()->family); ?>

                                    <?php endif; ?>
                                    </span></td>
                                    <td class="datatable-cell text-center"><span>

                                    <?php if($curt->guid_id): ?>
                                    <?php echo e($curt->guid->name); ?>

                                    <?php echo e($curt->guid->family); ?>

                                    <?php endif; ?>
                                    </span></td>
                                    <td class="datatable-cell text-center"><span>

                                    <?php if($curt->group_id): ?>
                                    <?php echo e($curt->group->name); ?>

                                  (  <?php echo e($curt->group->admin()->name); ?>

                                  <?php echo e($curt->group->admin()->family); ?>)
                                    <?php endif; ?>
                                    </span></td>





                                    <td class="datatable-cell text-center">
                                        <span><?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('Y-m-d')); ?>

                                        </span>
                                    </td>
                                    <td class="datatable-cell text-center">

                                        <a class="btn btn-success"
                                        href="<?php echo e(route('agent.statement.pdf',$curt->id)); ?>"><?php echo e(__('sentences.more')); ?> </a>
                                    </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>

                            <?php echo e($curts->appends(Request::all())->links('sections.pagination')); ?>


                    </div>
                    <!--end: جدول داده ها-->
                </div>
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/agent/statement.blade.php ENDPATH**/ ?>