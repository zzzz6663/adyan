<?php $__env->startSection('main'); ?>
    <!--begin::Content-->
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
        <!--begin::Entry-->
        <div class="d-flex flex-column-fluid">
            <!--begin::Container-->
            <div class=" container ">


                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="card card-custom card-stretch gutter-b">
                            <!--begin::Header-->
                            <div class="card-header border-0">
                                <h3 id="quiz_p" class="card-title font-weight-bolder text-dark">  زمان </h3>
                                <div id="progressBar" data-time="<?php echo e($questions->count()*5); ?>">
                                    <div class="bar"></div>
                                  </div>

                            </div>
                            <!--end::Header-->

                            <!--begin::Body-->
                            <div class="card-body pt-0">
                                <form id="quiz_form" action="<?php echo e(route('student.quiz.result')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <ul class="row" style="list-style: none">
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="col-lg-6">

                                                <div class="form-group   border-primary p-5">
                                                    <label class="mb-5">
                                                            <?php echo e($loop->iteration); ?>-
                                                        <?php echo e($question->question); ?>


                                                    <?php echo e($question->answer); ?>

                                                    </label>
                                                    <div class="radio-">
                                                        <input type="text" hidden name="quiz_id" value="<?php echo e($quiz->id); ?>">
                                                        <input type="text" hidden name="number" value="<?php echo e($number); ?>">
                                                        <input type="text" hidden name="answer[<?php echo e($question->id); ?>]">
                                                        <label class="radio radio-lg mb-5">
                                                            <input type="radio"  name="answer[<?php echo e($question->id); ?>]" value="1">
                                                            <span></span>
                                                           <?php echo e($question->a1); ?>

                                                        </label>
                                                        <label class="radio radio-lg mb-5">
                                                            <input type="radio" name="answer[<?php echo e($question->id); ?>]" value="2">
                                                            <span></span>
                                                            <?php echo e($question->a2); ?>

                                                        </label>
                                                        <label class="radio radio-lg mb-5">
                                                            <input type="radio" name="answer[<?php echo e($question->id); ?>]" value="3">
                                                            <span></span>
                                                            <?php echo e($question->a3); ?>

                                                        </label>
                                                        <label class="radio radio-lg mb-5">
                                                            <input type="radio" name="answer[<?php echo e($question->id); ?>]"  value="4">
                                                            <span></span>
                                                            <?php echo e($question->a4); ?>

                                                        </label>
                                                    </div>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>


                                    <span id="finish_butt" class="btn btn-danger" ><?php echo e(__('sentences.end_quiz')); ?></span>
                                    <h1 class="finish_zone hide" >
                                        <?php echo e(__('sentences.for_end_quiz')); ?>


                                    </h1>
                                    <input id=""   type="submit" value="<?php echo e(__('sentences.end')); ?>" class="btn btn-primary finish_zone hide" >
                                    <span id="cancel_finish_butt" class="btn btn-success  hide finish_zone" ><?php echo e(__('sentences.i_continue')); ?>

                                    </span>
                                </form>

                            </div>
                            <!--end::Body-->
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Container-->
        </div>
    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/student/quiz.blade.php ENDPATH**/ ?>