<?php $__env->startSection('message'); ?>
<?php echo e($payam); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('email.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/email/message.blade.php ENDPATH**/ ?>