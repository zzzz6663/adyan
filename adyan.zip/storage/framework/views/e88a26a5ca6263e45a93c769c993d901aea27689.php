<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">


            <!--begin::Card-->
            <div class="card card-custom">
                <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title">
                        <h3 class="card-label">
                            جدول کاربران
                             <span class="text-muted pt-2 font-size-sm d-block">
                               لیست اساتید  و دانشجویان و متخصصان و مدیران گروه
                            </span>
                        </h3>
                    </div>
                    <div class="card-toolbar">
                        

                        <!--begin::دکمه-->
                        <a href="<?php echo e(route('agent.create')); ?>" class="btn btn-primary font-weight-bolder">
                            <span class="svg-icon svg-icon-md">
                                <!--begin::Svg Icon | path:assets/media/svg/icons/طرح/Flatten.svg--><svg
                                    xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                    width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <rect x="0" y="0" width="24" height="24"></rect>
                                        <circle fill="#000000" cx="9" cy="15" r="6"></circle>
                                        <path
                                            d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z"
                                            fill="#000000" opacity="0.3"></path>
                                    </g>
                                </svg>
                                <!--end::Svg Icon-->
                            </span> جدید رکورد
                        </a>
                        <!--end::دکمه-->
                    </div>
                </div>
                <div class="card-body">
                    <!--begin: جستجو Form-->
                    <!--begin::جستجو Form-->
                    <div class="mb-7">
                        <div class="row align-items-center">
                            <div class="col-lg-9 col-xl-8">
                                <div class="row align-items-center">
                                    <div class="col-md-4 my-2 my-md-0">
                                        <div class="input-icon">
                                            <input type="text" class="form-control" placeholder="جستجو..."
                                                id="kt_datatable_search_query">
                                            <span><i class="flaticon2-search-1 text-muted"></i></span>
                                        </div>
                                    </div>

                                    <div class="col-md-4 my-2 my-md-0">
                                        <div class="d-flex align-items-center">
                                            <label class="mr-3 mb-0 d-none d-md-block">وضعیت:</label>
                                            <div class="dropdown bootstrap-select form-control"><select
                                                    class="form-control" id="kt_datatable_search_status">
                                                    <option value="">همه</option>
                                                    <option value="1">در انتظار</option>
                                                    <option value="2">تحویل داده شده</option>
                                                    <option value="3">لغو شده</option>
                                                    <option value="4">موفقیت</option>
                                                    <option value="5">اطلاعات</option>
                                                    <option value="6">هشدار</option>
                                                </select><button type="button" tabindex="-1"
                                                    class="btn dropdown-toggle btn-light bs-placeholder"
                                                    data-toggle="dropdown" role="combobox" aria-owns="bs-select-1"
                                                    aria-haspopup="listbox" aria-expanded="false"
                                                    data-id="kt_datatable_search_status" title="همه">
                                                    <div class="filter-option">
                                                        <div class="filter-option-inner">
                                                            <div class="filter-option-inner-inner">همه</div>
                                                        </div>
                                                    </div>
                                                </button>
                                                <div class="dropdown-menu ">
                                                    <div class="inner show" role="listbox" id="bs-select-1"
                                                        tabindex="-1">
                                                        <ul class="dropdown-menu inner show" role="presentation"></ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 my-2 my-md-0">
                                        <div class="d-flex align-items-center">
                                            <label class="mr-3 mb-0 d-none d-md-block">نوع:</label>
                                            <div class="dropdown bootstrap-select form-control"><select
                                                    class="form-control" id="kt_datatable_search_type">
                                                    <option value="">همه</option>
                                                    <option value="1">Online</option>
                                                    <option value="2">Retail</option>
                                                    <option value="3">Direct</option>
                                                </select><button type="button" tabindex="-1"
                                                    class="btn dropdown-toggle btn-light bs-placeholder"
                                                    data-toggle="dropdown" role="combobox" aria-owns="bs-select-2"
                                                    aria-haspopup="listbox" aria-expanded="false"
                                                    data-id="kt_datatable_search_type" title="همه">
                                                    <div class="filter-option">
                                                        <div class="filter-option-inner">
                                                            <div class="filter-option-inner-inner">همه</div>
                                                        </div>
                                                    </div>
                                                </button>
                                                <div class="dropdown-menu ">
                                                    <div class="inner show" role="listbox" id="bs-select-2"
                                                        tabindex="-1">
                                                        <ul class="dropdown-menu inner show" role="presentation"></ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-xl-4 mt-5 mt-lg-0">
                                <a href="#" class="btn btn-light-primary px-6 font-weight-bold">
                                    جستجو
                                </a>
                            </div>
                        </div>
                    </div>
                    <!--end::جستجو Form-->
                    <!--end: جستجو Form-->

                    <!--begin: جدول داده ها-->
                    <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                        id="kt_datatable" style="">
                        <table class="datatable-table" >
                            <thead class="datatable-head">
                                <tr class="datatable-row" style="left: 0px;">

                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            ID
                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            نام
                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            نام خانوادگی
                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            همراه
                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            سطح
                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            تاریخ عضویت
                                        </span>
                                    </th>
                                    <th class="datatable-cell datatable-cell-sort text-center">
                                        <span>
                                            اقدام
                                        </span>
                                    </th>

                                </tr>
                            </thead>
                            <tbody class="datatable-body" style="">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="datatable-row" style="left: 0px;">
                                    <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?> </span></td>
                                    <td class="datatable-cell text-center"><span><?php echo e($user->name); ?> </span></td>
                                    <td class="datatable-cell text-center"><span><?php echo e($user->family); ?> </span></td>
                                    <td class="datatable-cell text-center"><span><?php echo e($user->mobile); ?> </span></td>
                                    <td class="datatable-cell text-center"><span><?php echo e(__('arr.'.$user->level)); ?> </span>
                                    </td>
                                    <td class="datatable-cell text-center">
                                        <span><?php echo e(Morilog\Jalali\Jalalian::forge($user->created_at)->format('Y-m-d')); ?>

                                        </span>
                                    </td>
                                    <td class="datatable-cell text-center">
                                        <?php if($user->level !='student'): ?>
                                        <a class="btn btn-outline-primary"
                                            href="<?php echo e(route('agent.edit',$user->id)); ?>">ویرایش</a>
                                        <?php endif; ?>
                                        <?php if($user->level=='student' &&$user->verify==0): ?>
                                        <a class="btn btn-outline-success"
                                            href="<?php echo e(route('admin.verify.student',$user->id)); ?>">اکتیو</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>

                            <?php echo e($users->appends(Request::all())->links('sections.pagination')); ?>


                    </div>
                    <!--end: جدول داده ها-->
                </div>
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/agent/all.blade.php ENDPATH**/ ?>