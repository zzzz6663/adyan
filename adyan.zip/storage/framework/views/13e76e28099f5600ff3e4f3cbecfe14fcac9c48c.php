<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">



                <div class="col-xxl-12 order-2 order-xxl-1">
                    <!--begin::پیشرفت Table Widget 2-->
                    <div class="card card-custom card-stretch gutter-b">
                        <!--begin::Header-->
                        <div class="card-header border-0 pt-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark"> <?php echo e(__('sentences.my_group')); ?>  </span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm"> </span>
                            </h3>

                        </div>
                        <!--end::Header-->

                        <!--begin::Body-->
                        <div class="card-body pt-3 pb-0">
                            <!--begin::Table-->
                            <div class="table-responsive">
                                <!--begin: جدول داده ها-->
                                <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                    id="kt_datatable" style="">
                                    <table class="datatable-table">
                                        <thead class="datatable-head">
                                            <tr class="datatable-row" style="left: 0px;">

                                                <th class="datatable-cell datatable-cell-sort text-center">
                                                    <span>
                                                        <?php echo e(__('sentences.id')); ?>

                                                    </span>
                                                </th>
                                                <th class="datatable-cell datatable-cell-sort text-center">
                                                    <span>
                                                        <?php echo e(__('sentences.name')); ?>

                                                    </span>
                                                </th>
                                                <th class="datatable-cell datatable-cell-sort text-center">
                                                    <span>
                                                        <?php echo e(__('sentences.members')); ?>

                                                    </span>
                                                </th>
                                                <th class="datatable-cell datatable-cell-sort text-center">
                                                    <span>
                                                        <?php echo e(__('sentences.created_at')); ?>

                                                    </span>
                                                </th>


                                            </tr>
                                        </thead>
                                        <tbody class="datatable-body" style="">
                                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="datatable-row" style="left: 0px;">
                                                <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?>

                                                    </span></td>
                                                <td class="datatable-cell text-center"><span><?php echo e($group->name); ?> </span>
                                                </td>
                                                <td class="datatable-cell text-center">
                                                    <span>
                                                 <?php $__currentLoopData = $group->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span>(
                                                            <?php echo e($user->name); ?>

                                                            <?php echo e($user->family); ?>


                                                            )</span>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </span>
                                                </td>

                                                <td class="datatable-cell text-center">
                                                    <span><?php echo e(Morilog\Jalali\Jalalian::forge($group->created_at)->format('Y-m-d')); ?>

                                                    </span>
                                                </td>

                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </tbody>
                                    </table>

                                    

                                </div>
                                <!--end: جدول داده ها-->
                            </div>
                            <!--end::Table-->
                        </div>
                        <!--end::Body-->
                    </div>
                    <!--end::پیشرفت Table Widget 2-->
                </div>

            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/master/groups.blade.php ENDPATH**/ ?>