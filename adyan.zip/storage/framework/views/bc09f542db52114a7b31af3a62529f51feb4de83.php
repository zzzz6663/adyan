
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="row">
                <!--begin::Aside-->
                <div class="col-lg-12" id="kt_profile_aside">
                    <!--begin::Card-->
                    <div class="card card-custom gutter-b">
                        <!--begin::Body-->
                        <div class="card-body pt-4">


                            <!--begin::User-->
                            <div class="d-flex align-items-center">
                                <div
                                    class="symbol text-center mb-10 symbol-60 symbol-xxl-100 mr-5 align-self-start align-self-xxl-center">
                                    <div class="symbol-label" style="background-image:url('<?php echo e($user->avatar()); ?>')">
                                    </div>
                                    <?php if($user->level=='student'): ?>

                                    <h4 class="font-weight-bold my-2">
                                        <?php echo e(__('sentences.last_status' )); ?>

                                                    :
                                        <?php echo e(__('sentences.' . $user->status)); ?>

                                    </h4>
                                    <?php endif; ?>

                                    <i class="symbol-badge bg-success"></i>
                                </div>
                                <div>
                                    <a href="#" class="font-weight-bold font-size-h5 text-dark-75 text-hover-primary">
                                        <?php echo e($user->name); ?>

                                        <?php echo e($user->family); ?>

                                    </a>
                                    <div class="text-muted">
                                        <?php echo e(__('sentences.' . $user->level)); ?>

                                    </div>
                                    
                                </div>
                            </div>
                            <!--end::User-->

                            <!--begin::مخاطب-->
                            <div class="pt-8 pb-6">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">

                                        <?php echo e(__('sentences.email')); ?> :</span>
                                    <a href="#" class="text-muted text-hover-primary"> <?php echo e($user->email); ?> </a>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.mobile')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->mobile); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.code')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->code); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.group')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->group); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.whatsapp')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->whatsapp); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.type_job')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->type_job); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.semat_job')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->semat_job); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.job')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->job); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.org')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->org); ?>

                                    </span>
                                </div>
                                <?php if(auth()->check() && auth()->user()->hasRole('srudent')): ?>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.country')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->country->fa_name); ?>

                                    </span>
                                </div>
                                <?php endif; ?>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.defend_status')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->defend=='1'?             __('sentences.defended')  :''); ?>

                                        <?php echo e($user->defend=='0'?              __('sentences.undefended') :''); ?>

                                    </span>
                                </div>

                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.province')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->province); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.city')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->city); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.master_univer')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->master_univer); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.master_course')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->master_course); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.expert_abi')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->expert); ?>

                                    </span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="font-weight-bold mr-2">
                                        <?php echo e(__('sentences.course')); ?> :</span>
                                    <span class="text-muted">
                                        <?php echo e($user->course); ?>

                                    </span>
                                </div>


                            </div>
                            <!--end::مخاطب-->

                            
                        </div>
                        <!--end::Body-->
                    </div>
                    <!--end::Card-->


                </div>
                <!--end::Aside-->

                <!--begin::Content-->
                <div class="col-lg-12">

                    <div class="row">

                        <div class="col-xl-12">
                            <!--begin::Card-->
                            <div class="card card-custom gutter-b">
                                <!--begin::Header-->
                                <div class="card-header card-header-tabs-line">
                                    <div class="card-toolbar">
                                        <ul class="nav nav-tabs nav-tabs-space-lg nav-tabs-line nav-bold nav-tabs-line-3x"
                                            role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" data-toggle="tab" href="#logs">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/general/اطلاع2.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M13.2070325,4 C13.0721672,4.47683179 13,4.97998812 13,5.5 C13,8.53756612 15.4624339,11 18.5,11 C19.0200119,11 19.5231682,10.9278328 20,10.7929675 L20,17 C20,18.6568542 18.6568542,20 17,20 L7,20 C5.34314575,20 4,18.6568542 4,17 L4,7 C4,5.34314575 5.34314575,4 7,4 L13.2070325,4 Z"
                                                                        fill="#000000"></path>
                                                                    <circle fill="#000000" opacity="0.3" cx="18.5"
                                                                        cy="5.5" r="2.5"></circle>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.logs')); ?>

                                                    </span>
                                                </a>
                                            </li>
                                            <?php if($user->level == 'master'): ?>
                                            <li class="nav-item mr-3">
                                                <a class="nav-link" data-toggle="tab" href="#groups">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/ارتباطات/چت-check.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M4.875,20.75 C4.63541667,20.75 4.39583333,20.6541667 4.20416667,20.4625 L2.2875,18.5458333 C1.90416667,18.1625 1.90416667,17.5875 2.2875,17.2041667 C2.67083333,16.8208333 3.29375,16.8208333 3.62916667,17.2041667 L4.875,18.45 L8.0375,15.2875 C8.42083333,14.9041667 8.99583333,14.9041667 9.37916667,15.2875 C9.7625,15.6708333 9.7625,16.2458333 9.37916667,16.6291667 L5.54583333,20.4625 C5.35416667,20.6541667 5.11458333,20.75 4.875,20.75 Z"
                                                                        fill="#000000" fill-rule="nonzero"
                                                                        opacity="0.3"></path>
                                                                    <path
                                                                        d="M2,11.8650466 L2,6 C2,4.34314575 3.34314575,3 5,3 L19,3 C20.6568542,3 22,4.34314575 22,6 L22,15 C22,15.0032706 21.9999948,15.0065399 21.9999843,15.009808 L22.0249378,15 L22.0249378,19.5857864 C22.0249378,20.1380712 21.5772226,20.5857864 21.0249378,20.5857864 C20.7597213,20.5857864 20.5053674,20.4804296 20.317831,20.2928932 L18.0249378,18 L12.9835977,18 C12.7263047,14.0909841 9.47412135,11 5.5,11 C4.23590829,11 3.04485894,11.3127315 2,11.8650466 Z M6,7 C5.44771525,7 5,7.44771525 5,8 C5,8.55228475 5.44771525,9 6,9 L15,9 C15.5522847,9 16,8.55228475 16,8 C16,7.44771525 15.5522847,7 15,7 L6,7 Z"
                                                                        fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.my_group')); ?>

                                                    </span>
                                                </a>
                                            </li>

                                            <li class="nav-item mr-3">
                                                <a class="nav-link" data-toggle="tab" href="#sessions">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/Devices/Display1.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M11,20 L11,17 C11,16.4477153 11.4477153,16 12,16 C12.5522847,16 13,16.4477153 13,17 L13,20 L15.5,20 C15.7761424,20 16,20.2238576 16,20.5 C16,20.7761424 15.7761424,21 15.5,21 L8.5,21 C8.22385763,21 8,20.7761424 8,20.5 C8,20.2238576 8.22385763,20 8.5,20 L11,20 Z"
                                                                        fill="#000000" opacity="0.3"></path>
                                                                    <path
                                                                        d="M3,5 L21,5 C21.5522847,5 22,5.44771525 22,6 L22,16 C22,16.5522847 21.5522847,17 21,17 L3,17 C2.44771525,17 2,16.5522847 2,16 L2,6 C2,5.44771525 2.44771525,5 3,5 Z M4.5,8 C4.22385763,8 4,8.22385763 4,8.5 C4,8.77614237 4.22385763,9 4.5,9 L13.5,9 C13.7761424,9 14,8.77614237 14,8.5 C14,8.22385763 13.7761424,8 13.5,8 L4.5,8 Z M4.5,10 C4.22385763,10 4,10.2238576 4,10.5 C4,10.7761424 4.22385763,11 4.5,11 L7.5,11 C7.77614237,11 8,10.7761424 8,10.5 C8,10.2238576 7.77614237,10 7.5,10 L4.5,10 Z"
                                                                        fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.my_session')); ?>

                                                    </span>
                                                </a>
                                            </li>
                                            <li class="nav-item mr-3">
                                                <a class="nav-link" data-toggle="tab" href="#subjects">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/Devices/Display1.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M11,20 L11,17 C11,16.4477153 11.4477153,16 12,16 C12.5522847,16 13,16.4477153 13,17 L13,20 L15.5,20 C15.7761424,20 16,20.2238576 16,20.5 C16,20.7761424 15.7761424,21 15.5,21 L8.5,21 C8.22385763,21 8,20.7761424 8,20.5 C8,20.2238576 8.22385763,20 8.5,20 L11,20 Z"
                                                                        fill="#000000" opacity="0.3"></path>
                                                                    <path
                                                                        d="M3,5 L21,5 C21.5522847,5 22,5.44771525 22,6 L22,16 C22,16.5522847 21.5522847,17 21,17 L3,17 C2.44771525,17 2,16.5522847 2,16 L2,6 C2,5.44771525 2.44771525,5 3,5 Z M4.5,8 C4.22385763,8 4,8.22385763 4,8.5 C4,8.77614237 4.22385763,9 4.5,9 L13.5,9 C13.7761424,9 14,8.77614237 14,8.5 C14,8.22385763 13.7761424,8 13.5,8 L4.5,8 Z M4.5,10 C4.22385763,10 4,10.2238576 4,10.5 C4,10.7761424 4.22385763,11 4.5,11 L7.5,11 C7.77614237,11 8,10.7761424 8,10.5 C8,10.2238576 7.77614237,10 7.5,10 L4.5,10 Z"
                                                                        fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.my_subject')); ?>

                                                    </span>
                                                </a>
                                            </li>
                                            <li class="nav-item mr-3">
                                                <a class="nav-link" data-toggle="tab" href="#surveys">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/Devices/Display1.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M11,20 L11,17 C11,16.4477153 11.4477153,16 12,16 C12.5522847,16 13,16.4477153 13,17 L13,20 L15.5,20 C15.7761424,20 16,20.2238576 16,20.5 C16,20.7761424 15.7761424,21 15.5,21 L8.5,21 C8.22385763,21 8,20.7761424 8,20.5 C8,20.2238576 8.22385763,20 8.5,20 L11,20 Z"
                                                                        fill="#000000" opacity="0.3"></path>
                                                                    <path
                                                                        d="M3,5 L21,5 C21.5522847,5 22,5.44771525 22,6 L22,16 C22,16.5522847 21.5522847,17 21,17 L3,17 C2.44771525,17 2,16.5522847 2,16 L2,6 C2,5.44771525 2.44771525,5 3,5 Z M4.5,8 C4.22385763,8 4,8.22385763 4,8.5 C4,8.77614237 4.22385763,9 4.5,9 L13.5,9 C13.7761424,9 14,8.77614237 14,8.5 C14,8.22385763 13.7761424,8 13.5,8 L4.5,8 Z M4.5,10 C4.22385763,10 4,10.2238576 4,10.5 C4,10.7761424 4.22385763,11 4.5,11 L7.5,11 C7.77614237,11 8,10.7761424 8,10.5 C8,10.2238576 7.77614237,10 7.5,10 L4.5,10 Z"
                                                                        fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.my_surveys')); ?>

                                                    </span>
                                                </a>
                                            </li>
                                            <li class="nav-item mr-3">
                                                <a class="nav-link" data-toggle="tab" href="#mycurts">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/Devices/Display1.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M11,20 L11,17 C11,16.4477153 11.4477153,16 12,16 C12.5522847,16 13,16.4477153 13,17 L13,20 L15.5,20 C15.7761424,20 16,20.2238576 16,20.5 C16,20.7761424 15.7761424,21 15.5,21 L8.5,21 C8.22385763,21 8,20.7761424 8,20.5 C8,20.2238576 8.22385763,20 8.5,20 L11,20 Z"
                                                                        fill="#000000" opacity="0.3"></path>
                                                                    <path
                                                                        d="M3,5 L21,5 C21.5522847,5 22,5.44771525 22,6 L22,16 C22,16.5522847 21.5522847,17 21,17 L3,17 C2.44771525,17 2,16.5522847 2,16 L2,6 C2,5.44771525 2.44771525,5 3,5 Z M4.5,8 C4.22385763,8 4,8.22385763 4,8.5 C4,8.77614237 4.22385763,9 4.5,9 L13.5,9 C13.7761424,9 14,8.77614237 14,8.5 C14,8.22385763 13.7761424,8 13.5,8 L4.5,8 Z M4.5,10 C4.22385763,10 4,10.2238576 4,10.5 C4,10.7761424 4.22385763,11 4.5,11 L7.5,11 C7.77614237,11 8,10.7761424 8,10.5 C8,10.2238576 7.77614237,10 7.5,10 L4.5,10 Z"
                                                                        fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.mycurts')); ?>

                                                    </span>
                                                </a>
                                            </li>
                                            <li class="nav-item mr-3">
                                                <a class="nav-link" data-toggle="tab" href="#myplans">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/Devices/Display1.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M11,20 L11,17 C11,16.4477153 11.4477153,16 12,16 C12.5522847,16 13,16.4477153 13,17 L13,20 L15.5,20 C15.7761424,20 16,20.2238576 16,20.5 C16,20.7761424 15.7761424,21 15.5,21 L8.5,21 C8.22385763,21 8,20.7761424 8,20.5 C8,20.2238576 8.22385763,20 8.5,20 L11,20 Z"
                                                                        fill="#000000" opacity="0.3"></path>
                                                                    <path
                                                                        d="M3,5 L21,5 C21.5522847,5 22,5.44771525 22,6 L22,16 C22,16.5522847 21.5522847,17 21,17 L3,17 C2.44771525,17 2,16.5522847 2,16 L2,6 C2,5.44771525 2.44771525,5 3,5 Z M4.5,8 C4.22385763,8 4,8.22385763 4,8.5 C4,8.77614237 4.22385763,9 4.5,9 L13.5,9 C13.7761424,9 14,8.77614237 14,8.5 C14,8.22385763 13.7761424,8 13.5,8 L4.5,8 Z M4.5,10 C4.22385763,10 4,10.2238576 4,10.5 C4,10.7761424 4.22385763,11 4.5,11 L7.5,11 C7.77614237,11 8,10.7761424 8,10.5 C8,10.2238576 7.77614237,10 7.5,10 L4.5,10 Z"
                                                                        fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.myplans')); ?>

                                                    </span>
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                            <?php if($user->level == 'expert'): ?>
                                            <li class="nav-item mr-3">
                                                <a class="nav-link" data-toggle="tab" href="#quizizz">
                                                    <span class="nav-icon mr-2">
                                                        <span class="svg-icon mr-3">
                                                            <!--begin::Svg Icon | path:assets/media/svg/icons/Devices/Display1.svg--><svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                                                                height="24px" viewBox="0 0 24 24" version="1.1">
                                                                <g stroke="none" stroke-width="1" fill="none"
                                                                    fill-rule="evenodd">
                                                                    <rect x="0" y="0" width="24" height="24"></rect>
                                                                    <path
                                                                        d="M11,20 L11,17 C11,16.4477153 11.4477153,16 12,16 C12.5522847,16 13,16.4477153 13,17 L13,20 L15.5,20 C15.7761424,20 16,20.2238576 16,20.5 C16,20.7761424 15.7761424,21 15.5,21 L8.5,21 C8.22385763,21 8,20.7761424 8,20.5 C8,20.2238576 8.22385763,20 8.5,20 L11,20 Z"
                                                                        fill="#000000" opacity="0.3"></path>
                                                                    <path
                                                                        d="M3,5 L21,5 C21.5522847,5 22,5.44771525 22,6 L22,16 C22,16.5522847 21.5522847,17 21,17 L3,17 C2.44771525,17 2,16.5522847 2,16 L2,6 C2,5.44771525 2.44771525,5 3,5 Z M4.5,8 C4.22385763,8 4,8.22385763 4,8.5 C4,8.77614237 4.22385763,9 4.5,9 L13.5,9 C13.7761424,9 14,8.77614237 14,8.5 C14,8.22385763 13.7761424,8 13.5,8 L4.5,8 Z M4.5,10 C4.22385763,10 4,10.2238576 4,10.5 C4,10.7761424 4.22385763,11 4.5,11 L7.5,11 C7.77614237,11 8,10.7761424 8,10.5 C8,10.2238576 7.77614237,10 7.5,10 L4.5,10 Z"
                                                                        fill="#000000"></path>
                                                                </g>
                                                            </svg>
                                                            <!--end::Svg Icon-->
                                                        </span> </span>
                                                    <span class="nav-text">
                                                        <?php echo e(__('sentences.my_quiz')); ?>

                                                    </span>
                                                </a>
                                            </li>
                                            <?php endif; ?>


                                        </ul>
                                    </div>
                                </div>
                                <!--end::Header-->

                                <!--begin::Body-->
                                <div class="card-body px-0">
                                    <div class="tab-content pt-5">
                                        <!--begin::Tab Content-->
                                        <div class="tab-pane active" id="logs" role="tabpanel">
                                            <div class="container">


                                                <div class="separator separator-dashed my-10">


                                                </div>
                                                <?php if(auth()->check() && auth()->user()->hasRole('admin|master')): ?>
                                                <!--begin::تایم لاین-->
                                                <div class="timeline timeline-3">
                                                    <div class="timeline-items">
                                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="timeline-item">
                                                            <div class="timeline-media">
                                                                <?php switch($log->type):
                                                                case ('register'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('verify'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('pass_quiz'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('submit_curt'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('edit_curt_by_student'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('save_curt_group_by_expert'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('review_curt_by_master'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('select_curt_master'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>
                                                                <?php case ('select_curt_guid'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('accept_curt'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('submit_subject'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('submit_plan'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('edit_plan_by_student'): ?>
                                                                <img alt="Pic"
                                                                    src="<?php echo e($log->group->admin()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('accept_plan'): ?>
                                                                <img alt="Pic"
                                                                    src="<?php echo e($log->group->admin()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('create_subject'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('subject_result'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('submit_survey'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('answer_survey'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('confirm_plan'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('submit_plan_master'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('edit_plan_by_student_from_master'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php case ('select_plan_guid'): ?>
                                                                <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                                <?php break; ?>

                                                                <?php default: ?>
                                                                <?php endswitch; ?>
                                                            </div>
                                                            <div class="timeline-content">
                                                                <div
                                                                    class="d-flex align-items-center justify-content-between mb-3">
                                                                    <div class="mr-2">
                                                                        <a href="#"
                                                                            class="text-dark-75 text-hover-primary font-weight-bold">
                                                                            <?php echo e($log->type); ?>

                                                                            <?php switch($log->type):
                                                                            case ('register'): ?>
                                                                            <?php echo e(__('sentences.register')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('verify'): ?>
                                                                            <?php echo e(__('sentences.verify_regiter')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('pass_quiz'): ?>
                                                                            <?php echo e(__('sentences.pass_quiz')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('submit_curt'): ?>
                                                                            <?php echo e(__('sentences.create_curt')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('edit_curt_by_student'): ?>
                                                                            <?php echo e(__('sentences.verify_curt_by_student')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('save_curt_group_by_expert'): ?>
                                                                            <?php echo e(__('sentences.save_curt_group_by_expert')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('review_curt_by_master'): ?>
                                                                            <?php echo e(__('sentences.review_curt_by_master')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('select_curt_master'): ?>
                                                                            <?php echo e(__('sentences.select_curt_master')); ?>

                                                                            <?php break; ?>
                                                                            <?php case ('select_curt_guid'): ?>
                                                                            <?php echo e(__('sentences.select_curt_guid')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('accept_curt'): ?>
                                                                            <?php echo e(__('sentences.accept_curt')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('submit_subject'): ?>
                                                                            <?php echo e(__('sentences.submit_subject_student_log')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('submit_plan'): ?>
                                                                            <?php echo e(__('sentences.submit_plan_student_log')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('edit_plan_by_student'): ?>
                                                                            <?php echo e(__('sentences.edit_plan_by_student_log')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('accept_plan'): ?>
                                                                            <?php echo e(__('sentences.accept_plan_student_log')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('create_subject'): ?>
                                                                            <?php echo e(__('sentences.create_subject')); ?>

                                                                            <?php break; ?>


                                                                            <?php break; ?>

                                                                            <?php case ('subject_result'): ?>
                                                                            <?php echo e(__('sentences.subject_result')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('submit_survey'): ?>
                                                                            <?php echo e(__('sentences.submit_survey')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('answer_survey'): ?>
                                                                            <?php echo e(__('sentences.answer_survey')); ?>

                                                                            <?php break; ?>



                                                                            <?php case ('confirm_plan'): ?>
                                                                            <?php echo e(__('sentences.confirm_plan_title')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('submit_plan_master'): ?>
                                                                            <?php echo e(__('sentences.submit_plan_student_log')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('edit_plan_by_student_from_master'): ?>
                                                                            <?php echo e(__('sentences.edit_plan_by_student_log')); ?>

                                                                            <?php break; ?>

                                                                            <?php case ('select_plan_guid'): ?>
                                                                            <?php echo e(__('sentences.select_plan_guid')); ?>

                                                                            <?php break; ?>

                                                                            <?php default: ?>
                                                                            <?php endswitch; ?>
                                                                        </a>
                                                                        <span class="text-muted ml-2">
                                                                            <?php echo e(Morilog\Jalali\Jalalian::forge($log->created_at)->format('d-m-Y')); ?>


                                                                        </span>
                                                                        <span
                                                                            class="label label-light-success font-weight-bolder label-inline ml-2">




                                                                        </span>
                                                                    </div>

                                                                </div>
                                                                <p class="p-0">
                                                                    <?php switch($log->type):
                                                                    case ('register'): ?>
                                                                    <?php echo e(__('sentences.register_student_logs', ['name' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('verify'): ?>
                                                                    <?php echo e(__('sentences.confirm_student_account_by_exprt',
                                                                    ['name' => $log->student()->name . ' ' .
                                                                    $log->student()->family,'expert' =>
                                                                    $log->operator()->name . ' ' .
                                                                    $log->operator()->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('pass_quiz'): ?>
                                                                    <?php echo e(__('sentences.pass_quiz_student', ['student' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('submit_curt'): ?>
                                                                    <?php echo e(__('sentences.submit_curt_by_student', ['student'
                                                                    => $log->student()->name . ' ' .
                                                                    $log->student()->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('edit_curt_by_student'): ?>
                                                                    <?php echo e(__('sentences.edit_curt_by_student', ['expert' =>
                                                                    $log->operator()->name . ' ' .
                                                                    $log->operator()->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('save_curt_group_by_expert'): ?>
                                                                    <?php echo e(__('sentences.save_curt_group_by_expert_log',
                                                                    ['expert' => $log->operator()->name . ' ' .
                                                                    $log->operator()->family,'group' =>
                                                                    $log->curt->group->name,'student' =>
                                                                    $log->curt->user->name . ' ' .
                                                                    $log->curt->user->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('review_curt_by_master'): ?>
                                                                    <?php echo e(__('sentences.review_curt_by_master_by_student',
                                                                    ['student' => $log->operator()->name . ' ' .
                                                                    $log->operator()->family,'group' =>
                                                                    $log->curt->group->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('select_curt_master'): ?>
                                                                    <?php echo e(__('sentences.select_curt_master_for_curt',
                                                                    ['master' => $log->curt->master()->name . ' ' .
                                                                    $log->curt->master()->family,'group' =>
                                                                    $log->curt->group->name])); ?>

                                                                    <?php break; ?>
                                                                    <?php case ('select_curt_guid'): ?>
                                                                    <?php echo e(__('sentences.select_curt_guid_for_curt',
                                                                    ['master' => $log->curt->master()->name . ' ' .
                                                                    $log->curt->master()->family,'group' =>
                                                                    $log->curt->group->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('accept_curt'): ?>
                                                                    <?php echo e(__('sentences.accept_curt_by_group', ['group' =>
                                                                    $log->curt->group->name,'student' =>
                                                                    $log->curt->user->name . ' ' .
                                                                    $log->curt->user->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('submit_subject'): ?>
                                                                    <?php echo e(__('sentences.submit_subject_student', ['subject'
                                                                    => $log->subject->title,'master' =>
                                                                    $log->subject->master->name . ' ' .
                                                                    $log->subject->master->family,'student' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('submit_plan'): ?>
                                                                    <?php echo e(__('sentences.submit_plan_log', ['student' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family,'group' =>
                                                                    $log->plan->group->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('edit_plan_by_student'): ?>
                                                                    <?php echo e(__('sentences.edit_plan_by_student', ['student'
                                                                    => $log->student()->name . ' ' .
                                                                    $log->student()->family,'group' =>
                                                                    $log->plan->group->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('accept_plan'): ?>
                                                                    <?php echo e(__('sentences.accept_plan_log', ['student' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family,'group' =>
                                                                    $log->plan->group->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('create_subject'): ?>
                                                                    <?php echo e(__('sentences.create_subject_log', ['master' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family,'subject' =>
                                                                    $log->subject->title,'group' => $log->group->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('subject_result'): ?>
                                                                    <?php echo e(__('sentences.subject_result_log', ['master' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family,'subject' =>
                                                                    $log->subject->title,'group' => $log->group->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('submit_survey'): ?>
                                                                    <?php echo e(__('sentences.survey_submit_log', ['master' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family,'name' =>
                                                                    $log->survey->name])); ?>

                                                                    <?php break; ?>

                                                                    <?php case ('answer_survey'): ?>
                                                                    <?php echo e(__('sentences.answer_survey_log', ['master' =>
                                                                    $log->student()->name . ' ' .
                                                                    $log->student()->family,'name' =>
                                                                    $log->survey->name])); ?>

                                                                    <?php break; ?>





                                                                    <?php case ('confirm_plan'): ?>
                                                                    <?php echo e(__('sentences.confirm_plan _log',['student'=>$log->student()->name.' '.$log->student()->family,'master'=>$log->operator()->name.' '.$log->operator()->family ])); ?>


                                                                    <?php break; ?>

                                                                    <?php case ('submit_plan_master'): ?>
                                                                    <?php echo e(__('sentences.submit_plan_master_log',['student'=>$log->student()->name.' '.$log->student()->family,'master'=>$log->operator()->name.' '.$log->operator()->family])); ?>


                                                                    <?php break; ?>

                                                                    <?php case ('edit_plan_by_student_from_master'): ?>
                                                                    <?php echo e(__('sentences.edit_plan_by_student_from_master',['student'=>$log->student()->name.' '.$log->student()->family,'master'=>$log->operator()->name.' '.$log->operator()->family ])); ?>


                                                                    <?php break; ?>

                                                                    <?php case ('select_plan_guid'): ?>
                                                                    <?php echo e(__('sentences.select_plan_guid_for_plan',['master'=>$log->plan->master->name.' '.$log->plan->master->family,'group'=>$log->plan->group->name])); ?>


                                                                    <?php break; ?>
                                                                    <?php default: ?>
                                                                    <?php endswitch; ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <!--end::تایم لاین-->
                                            </div>
                                        </div>
                                        <!--end::Tab Content-->


                                        <?php if($user->level == 'master'): ?>
                                        <!--begin::Tab Content-->
                                        <div class="tab-pane" id="groups" role="tabpanel">
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin|master')): ?>
                                            <!--begin: جدول داده ها-->
                                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                                id="kt_datatable" style="">
                                                <table class="datatable-table" style="display: block;">
                                                    <thead class="datatable-head">
                                                        <tr class="datatable-row" style="left: 0px;">

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.id')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.group_name')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.group_admin_name')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">

                                                                <span>
                                                                    <?php echo e(__('sentences.group_member')); ?>


                                                                </span>
                                                            </th>

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.created_at')); ?>


                                                                </span>
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody class="datatable-body" style="">
                                                        <?php $__currentLoopData = $user->groups()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usergroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="datatable-row" style="left: 0px;">
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($loop->iteration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($usergroup->name); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center"><span>
                                                                    <?php if($usergroup->user_id): ?>
                                                                    <?php echo e($usergroup->admin()->name); ?>

                                                                    <?php echo e($usergroup->admin()->family); ?>

                                                                    <?php endif; ?>

                                                                </span></td>
                                                            <td class="datatable-cell text-center"><span>
                                                                    <?php $__currentLoopData = $usergroup->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php echo e($userg->name); ?>

                                                                    <?php echo e($userg->family); ?>

                                                                    -
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </span></td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($usergroup->created_at)->format('Y-m-d')); ?>

                                                                </span>
                                                            </td>

                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>


                                            </div>
                                            <!--end: جدول داده ها-->
                                            <?php endif; ?>
                                        </div>
                                        <!--end::Tab Content-->

                                        <div class="tab-pane" id="sessions" role="tabpanel">
                                            <!--begin: جدول داده ها-->
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin|master')): ?>
                                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                                id="kt_datatable" style="">
                                                <table class="datatable-table" style="display: block;">
                                                    <thead class="datatable-head">
                                                        <tr class="datatable-row" style="left: 0px;">

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.id')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>

                                                                    <?php echo e(__('sentences.session_name')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>

                                                                    <?php echo e(__('sentences.session_admin')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>

                                                                    <?php echo e(__('sentences.session_member')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>

                                                                    <?php echo e(__('sentences.created_at')); ?>

                                                                </span>
                                                            </th>

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>

                                                                    <?php echo e(__('sentences.action')); ?>

                                                                </span>
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody class="datatable-body" style="">
                                                        <?php $__currentLoopData = $user->sessions()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usersession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="datatable-row" style="left: 0px;">
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($loop->iteration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($usersession->name); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center"><span>
                                                                    <?php if($usersession->user_id): ?>
                                                                    <?php echo e($usersession->user->name); ?>

                                                                    <?php echo e($usersession->user->family); ?>

                                                                    <?php endif; ?>

                                                                </span></td>
                                                            <td class="datatable-cell text-center"><span>
                                                                    <?php $__currentLoopData = $usersession->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php echo e($users->name); ?>

                                                                    <?php echo e($users->family); ?>

                                                                    -
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </span></td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($usersession->created_at)->format('Y-m-d')); ?>

                                                                </span>
                                                            </td>
                                                            <td>
                                                                <a class="btn btn-outline-primary"
                                                                    href="<?php echo e(route('admin.session.result', $usersession->id)); ?>">مشاهده</a>
                                                            </td>

                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>


                                            </div>
                                            <!--end: جدول داده ها-->
                                            <?php endif; ?>
                                        </div>



                                        <div class="tab-pane" id="subjects" role="tabpanel">
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin|master')): ?>
                                            <!--begin: جدول داده ها-->
                                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                                id="kt_datatable" style="">
                                                <table class="datatable-table" style="display: block;">
                                                    <thead class="datatable-head">
                                                        <tr class="datatable-row" style="left: 0px;">

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.id')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.subject_title')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.subject_admin')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.subject_user')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.status')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.info')); ?>

                                                                </span>
                                                            </th>

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.action')); ?>


                                                                </span>
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody class="datatable-body" style="">

                                                        <?php $__currentLoopData = $user->master_subjects()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usersubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="datatable-row" style="left: 0px;">
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($loop->iteration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($usersubject->title); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center"><span>
                                                                    <?php if($usersubject->admin_id): ?>
                                                                    <?php echo e($usersubject->admin->name); ?>

                                                                    <?php echo e($usersubject->admin->family); ?>

                                                                    <?php endif; ?>

                                                                </span></td>
                                                            <td class="datatable-cell text-center">
                                                                <span>

                                                                    <?php if($usersubject->user): ?>
                                                                    <?php echo e($usersubject->user->name); ?>

                                                                    <?php echo e($usersubject->user->family); ?>

                                                                    <?php endif; ?>
                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span>
                                                                    <?php switch($usersubject->status):
                                                                    case (null): ?>
                                                                    <?php echo e(__('sentences.in_progress')); ?>

                                                                    <?php break; ?>

                                                                    <?php case (1): ?>
                                                                    <?php echo e(__('sentences.confirmed')); ?>

                                                                    <?php break; ?>

                                                                    <?php case (0): ?>
                                                                    <?php echo e(__('sentences.failed')); ?>

                                                                    <?php break; ?>

                                                                    <?php default: ?>
                                                                    <?php endswitch; ?>
                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span>
                                                                    <?php echo e($usersubject->info); ?>

                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($usersubject->created_at)->format('Y-m-d')); ?>

                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">

                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>


                                            </div>
                                            <!--end: جدول داده ها-->
                                            <?php endif; ?>
                                        </div>

                                        <div class="tab-pane" id="surveys" role="tabpanel">
                                            <!--begin: جدول داده ها-->
                                            <?php if(auth()->check() && auth()->user()->hasRole('admin|master')): ?>
                                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                                id="kt_datatable" style="">
                                                <table class="datatable-table" style="display: block;">
                                                    <thead class="datatable-head">
                                                        <tr class="datatable-row" style="left: 0px;">

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.id')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.survey_name')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.survey_master')); ?>

                                                                </span>
                                                            </th>

                                                            <th class="datatable-cell datatable-cell-sort text-center">

                                                                <span>
                                                                    <?php echo e(__('sentences.survey_member')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.created_at')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.action')); ?>


                                                                </span>
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody class="datatable-body" style="">
                                                        <?php $__currentLoopData = $user->surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usersurvey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="datatable-row" style="left: 0px;">
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($loop->iteration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($usersurvey->name); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center"><span>
                                                                    <?php if($usersurvey->user_id): ?>
                                                                    <?php echo e($usersurvey->user->name); ?>

                                                                    <?php echo e($usersurvey->user->family); ?>

                                                                    <?php endif; ?>

                                                                </span></td>
                                                            <td class="datatable-cell text-center"><span>
                                                                    <?php $__currentLoopData = $usersurvey->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php echo e($userss->name); ?>

                                                                    <?php echo e($userss->family); ?>

                                                                    -
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </span></td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($usersurvey->created_at)->format('Y-m-d')); ?>

                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <a class="btn btn-outline-primary"
                                                                    href="<?php echo e(route('survey.show', $usersurvey->id)); ?>">مشاهده</a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>


                                            </div>
                                            <!--end: جدول داده ها-->
                                            <?php endif; ?>
                                        </div>

                                        <div class="tab-pane" id="mycurts" role="tabpanel">
                                            <!--begin: جدول داده ها-->
                                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                                id="kt_datatable" style="">
                                                <table class="datatable-table" style="display: block;">
                                                    <thead class="datatable-head">
                                                        <tr class="datatable-row" style="left: 0px;">

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.id')); ?>

                                                                </span>
                                                            </th>

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.title')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.student')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.last_change_student_date')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.action')); ?>


                                                                </span>
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody class="datatable-body" style="">
                                                        <?php $__currentLoopData = $user->master_curts()->whereType('primary')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mastercrut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="datatable-row" style="left: 0px;">
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($loop->iteration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($mastercrut->title); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span>
                                                                    <?php echo e($mastercrut->user->name); ?>

                                                                    <?php echo e($mastercrut->user->family); ?>

                                                                 </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span>
                                                                    <?php if($last_curt=$mastercrut->user->curts()->latest()->first()): ?>

                                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($last_curt->created_at)->format('Y-m-d')); ?>

                                                                <?php endif; ?>

                                                                </span>
                                                            </td>


                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($mastercrut->created_at)->format('Y-m-d')); ?>

                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>


                                            </div>
                                            <!--end: جدول داده ها-->
                                        </div>
                                        <div class="tab-pane" id="myplans" role="tabpanel">
                                            <!--begin: جدول داده ها-->
                                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                                id="kt_datatable" style="">
                                                <table class="datatable-table" style="display: block;">
                                                    <thead class="datatable-head">
                                                        <tr class="datatable-row" style="left: 0px;">

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.id')); ?>

                                                                </span>
                                                            </th>

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.title')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.student')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.last_change_student_date')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.action')); ?>


                                                                </span>
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody class="datatable-body" style="">
                                                        <?php $__currentLoopData = $user->master_plans()->whereType('primary')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $masterplan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="datatable-row" style="left: 0px;">
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($loop->iteration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($masterplan->title); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span>
                                                                    <?php echo e($masterplan->user->name); ?>

                                                                    <?php echo e($masterplan->user->family); ?>

                                                                 </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span>
                                                                    <?php if($last_plan=$masterplan->user->plans()->latest()->first()): ?>

                                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($last_plan->created_at)->format('Y-m-d')); ?>

                                                                <?php endif; ?>

                                                                </span>
                                                            </td>


                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($masterplan->created_at)->format('Y-m-d')); ?>

                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>


                                            </div>
                                            <!--end: جدول داده ها-->
                                        </div>
                                        <?php endif; ?>

                                        <?php if($user->level == 'expert'): ?>
                                        <div id="quizizz" class="tab-pane" role="tabpanel">
                                            <!--begin: جدول داده ها-->
                                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                                id="kt_datatable" style="">
                                                <table class="datatable-table" style="display: block;">
                                                    <thead class="datatable-head">
                                                        <tr class="datatable-row" style="left: 0px;">

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.id')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.quiz_name')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.question_count')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.question_duration')); ?>


                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.quiz_show_status')); ?>

                                                                </span>
                                                            </th>
                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.created_at')); ?>


                                                                </span>
                                                            </th>

                                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                                <span>
                                                                    <?php echo e(__('sentences.action')); ?>


                                                                </span>
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody class="datatable-body" style="">
                                                        <?php $__currentLoopData = $user->quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="datatable-row" style="left: 0px;">
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($loop->iteration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($quiz->title); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($quiz->questions()->count()); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e($quiz->duration); ?> </span>
                                                            </td>
                                                            <td class="datatable-cell text-center"><span
                                                                    class="text-<?php echo e($quiz->active=='1'?'success':'danger'); ?>"><?php echo e($quiz->active=='1'?'نمایش':'عدم
                                                                    نمایش'); ?> </span></td>


                                                            <td class="datatable-cell text-center">
                                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($quiz->created_at)->format('Y-m-d')); ?>

                                                                </span>
                                                            </td>
                                                            <td class="datatable-cell text-center">
                                                                
                                                                <a class="btn btn-outline-danger"
                                                                    href="<?php echo e(route('quiz.question.index',$quiz->id)); ?>">
                                                                    <?php echo e(__('sentences.questions')); ?></a>
                                                            </td>

                                                        </tr>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>


                                            </div>
                                            <!--end: جدول داده ها-->
                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <!--end::Body-->
                            </div>
                            <!--end::Card-->
                        </div>
                    </div>

                    <?php if($user->level=='student'): ?>
                    <!--begin::پیشرفت Table Widget 8-->
                    <div class="card card-custom gutter-b">
                        <!--begin::Header-->
                        <div class="card-header border-0 py-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark"><?php echo e(__('sentences.quizzez')); ?>

                                </span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm">
                                    <?php echo e(__('sentences.quizzez_list')); ?></span>
                            </h3>

                        </div>
                        <!--end::Header-->

                        <!--begin::Body-->
                        <div class="card-body pt-0 pb-3">
                            <!--begin::Table-->
                            <!--begin: جدول داده ها-->
                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                id="kt_datatable" style="">
                                <table class="datatable-table" style="display: block;">
                                    <thead class="datatable-head">
                                        <tr class="datatable-row" style="left: 0px;">

                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.id')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.quiz_name')); ?>


                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.question_count')); ?>


                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.question_duration')); ?>


                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.quiz_show_status')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.created_at')); ?>


                                                </span>
                                            </th>



                                        </tr>
                                    </thead>
                                    <tbody class="datatable-body" style="">
                                        <?php $__currentLoopData = $user->quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="datatable-row" style="left: 0px;">
                                            <td class="datatable-cell text-center"><span><?php echo e($loop->iteration); ?> </span>
                                            </td>
                                            <td class="datatable-cell text-center"><span><?php echo e($quiz->title); ?> </span></td>
                                            <td class="datatable-cell text-center"><span>
                                                    <?php echo e($user->questions()->wherePivot('number',
                                                    $quiz->pivot->number)->wherePivot('quiz_id', $quiz->id)->count()); ?>

                                                </span></td>
                                            <td class="datatable-cell text-center"><span><?php echo e($quiz->duration); ?> </span>
                                            </td>
                                            <td class="datatable-cell text-center"><span
                                                    class="text-<?php echo e($quiz->pivot->result=='1'?'success':'danger'); ?>"><?php echo e($quiz->pivot->result=='1'?
                                                    __('sentences.passed') : __('sentences.action')); ?> </span></td>
                                            <td class="datatable-cell text-center">
                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($quiz->pivot->time)->format('Y-m-d')); ?>

                                                </span>
                                            </td>

                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                </table>


                            </div>
                            <!--end: جدول داده ها-->
                            <!--end::Table-->
                        </div>
                        <!--end::Body-->
                    </div>
                    <!--end::پیشرفت Table Widget 8-->


                    <?php if($main_curt): ?>

                    <div class="card card-custom gutter-b">
                        <div class="card-header border-0 py-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark"><?php echo e(__('sentences.curts')); ?>

                                    <?php if($main_curt->subject): ?>
                                    <br>
                                    <?php echo e(__('sentences.curts_subject')); ?>

                                    <?php endif; ?>
                                </span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm">
                                    <?php echo e(__('sentences.curts_list')); ?></span>
                            </h3>


                        </div>
                        <?php if($main_curt->subject): ?>
                        <div class="card-body pt-0 pb-3">
                            <div class="datatable datatable-bordered datatable-head-custom datatable-default datatable-primary datatable-loaded"
                                id="kt_datatable" style="">
                                <table class="datatable-table" style="display: block;">
                                    <thead class="datatable-head">
                                        <tr class="datatable-row" style="left: 0px;">

                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.id')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.title')); ?>


                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.master')); ?>


                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.group')); ?>


                                                </span>
                                            </th>

                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.info')); ?>

                                                </span>
                                            </th>
                                            <th class="datatable-cell datatable-cell-sort text-center">
                                                <span>
                                                    <?php echo e(__('sentences.created_at')); ?>


                                                </span>
                                            </th>



                                        </tr>
                                    </thead>
                                    <tbody class="datatable-body" style="">

                                        <tr class="datatable-row" style="left: 0px;">
                                            <td class="datatable-cell text-center"><span>1 </span>
                                            </td>
                                            <td class="datatable-cell text-center">
                                                <span><?php echo e($main_curt->subject->title); ?> </span></td>
                                            <td class="datatable-cell text-center"><span>
                                                    <?php echo e($main_curt->subject->master->name); ?>

                                                </span></td>
                                            <td class="datatable-cell text-center"><span>
                                                    <?php echo e($main_curt->subject->group->name); ?> </span>
                                            </td>
                                            <td class="datatable-cell text-center"><span>
                                                    <?php echo e($main_curt->subject->info); ?> </span>
                                            </td>

                                            <td class="datatable-cell text-center">
                                                <span><?php echo e(Morilog\Jalali\Jalalian::forge($main_curt->subject->time)->format('Y-m-d')); ?>

                                                </span>
                                            </td>

                                        </tr>





                                    </tbody>
                                </table>


                            </div>
                        </div>
                        <?php else: ?>
                        <div class="card-body pt-0 pb-3">
                            <div class="row">
                                <div class="col-xl-12 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label class="card-title font-weight-bolder">
                                            <?php echo e(__('sentences.title')); ?>


                                        </label>
                                        <h2 class="">
                                            <?php echo e($main_curt->title); ?>

                                        </h2>
                                        <ul>
                                            <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $curt->title): ?>
                                            <li>

                                                (<?php echo e($curt->operator_curts()->name); ?>

                                                <?php echo e($curt->operator_curts()->family); ?>)
                                                (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                                <br>
                                                <?php echo e($curt->title); ?>

                                            </li>
                                            <?php endif; ?>


                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>

                                <div class="col-xl-12 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label class="card-title font-weight-bolder">
                                            <?php echo e(__('sentences.tags')); ?>


                                        </label>
                                        <h2 class="text-fs">
                                            <?php $__currentLoopData = $main_curt->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($tag->tag); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </h2>

                                        <ul>
                                            <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $curt->tag): ?>
                                            <li>
                                                (<?php echo e($curt->operator_curts()->name); ?>

                                                <?php echo e($curt->operator_curts()->family); ?>)
                                                (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                                <br>
                                                <?php echo e($curt->tag); ?>

                                            </li>
                                            <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-12 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label class="card-title font-weight-bolder">
                                            <?php echo e(__('sentences.problem')); ?>

                                        </label>
                                        <h2 class="text-fs">
                                            <?php echo e($main_curt->problem); ?>

                                        </h2>

                                        <ul>
                                            <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $curt->problem): ?>
                                            <li>
                                                (<?php echo e($curt->operator_curts()->name); ?>

                                                <?php echo e($curt->operator_curts()->family); ?>)
                                                (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                                <br>
                                                <?php echo e($curt->problem); ?>

                                            </li>
                                            <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-12 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label class="card-title font-weight-bolder">
                                            <?php echo e(__('sentences.question')); ?>

                                        </label>
                                        <h2 class="text-fs">
                                            <?php echo e($main_curt->question); ?>

                                        </h2>

                                        <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $curt->question): ?>
                                        <li>
                                            (<?php echo e($curt->operator_curts()->name); ?>

                                            <?php echo e($curt->operator_curts()->family); ?>)
                                            (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                            <br>
                                            <?php echo e($curt->question); ?>

                                        </li>
                                        <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="col-xl-12 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label class="card-title font-weight-bolder">
                                            <?php echo e(__('sentences.necessity')); ?>

                                        </label>
                                        <h2 class="text-fs">
                                            <?php echo e($main_curt->necessity); ?>

                                        </h2>

                                        <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $curt->necessity): ?>
                                        <li>
                                            (<?php echo e($curt->operator_curts()->name); ?>

                                            <?php echo e($curt->operator_curts()->family); ?>)
                                            (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                            <br>
                                            <?php echo e($curt->necessity); ?>

                                        </li>
                                        <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="col-xl-12 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label class="card-title font-weight-bolder">
                                            <?php echo e(__('sentences.innovation')); ?>

                                        </label>
                                        <h2 class="text-fs">
                                            <?php echo e($main_curt->innovation); ?>

                                        </h2>


                                        <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $curt->innovation): ?>
                                        <li>
                                            (<?php echo e($curt->operator_curts()->name); ?>

                                            <?php echo e($curt->operator_curts()->family); ?>)
                                            (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                            <br>
                                            <?php echo e($curt->innovation); ?>

                                        </li>
                                        <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php if(!$main_curt->master_id): ?>
                                <div class="col-xl-12 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label class="card-title font-weight-bolder">
                                            <?php if($main_curt->ostad()): ?>

                                            <?php echo e(__('sentences.suggested_master_list')); ?>

                                            <?php echo e($main_curt->ostad()->name); ?>

                                            <?php echo e($main_curt->ostad()->family); ?>


                                            <?php endif; ?>
                                            <br>
                                            <?php if($main_curt->ostad): ?>
                                            <?php echo e(__('sentences.suggested_master_out_list')); ?>

                                            <?php echo e($main_curt->ostad); ?>


                                            <a target="_blank" href="<?php echo e($main_curt->resume()); ?>" class="btn btn-danger">
                                                <?php echo e(__('sentences.download_resume')); ?> </a>

                                            <?php endif; ?>


                                        </label>

                                    </div>
                                </div>

                                <?php endif; ?>






                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>


                    <?php if($main_plan): ?>

                    <div class="card card-custom gutter-b">
                        <div class="card-header border-0 py-5">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label font-weight-bolder text-dark">
                                    <?php echo e(__('sentences.plan')); ?>



                                </span>
                                <span class="text-muted mt-3 font-weight-bold font-size-sm">
                                    <?php echo e(__('sentences.plan_list')); ?></span>
                            </h3>


                        </div>
                        <div class="card-body pt-0 pb-3">
                            <div class="row">
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.title')); ?>


                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->title); ?>

                                        </h2>

                                           <ul>
                                               <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <?php if( $plan->title): ?>
                                                  <li>

                                                    (<?php echo e($plan->group->admin()->name); ?>

                                                    <?php echo e($plan->group->admin()->family); ?>)
                                                    (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                                    <br>
                                                    <?php echo e($plan->title); ?>

                                                    </li>
                                               <?php endif; ?>


                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.en_title')); ?>


                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->en_title); ?>

                                        </h2>

                                           <ul>
                                               <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <?php if( $plan->en_title): ?>
                                                  <li>

                                                    (<?php echo e($plan->group->admin()->name); ?>

                                                    <?php echo e($plan->group->admin()->family); ?>)
                                                    (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                                    <br>
                                                    <?php echo e($plan->en_title); ?>

                                                    </li>
                                               <?php endif; ?>


                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </ul>
                                    </div>
                                </div>

                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.tags')); ?>


                                        </label>
                                        <h2>
                                            <?php $__currentLoopData = explode('_',$main_plan->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($tag); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </h2>

                                             <ul>
                                               <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <?php if( $plan->tags): ?>
                                                  <li>
                                                    (<?php echo e($plan->group->admin()->name); ?>

                                                    <?php echo e($plan->group->admin()->family); ?>)
                                                    (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                                    <br>
                                                    <?php echo e($plan->tags); ?>

                                                    </li>
                                               <?php endif; ?>

                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.en_tags')); ?>


                                        </label>
                                        <h2>
                                            <?php $__currentLoopData = explode('_',$main_plan->en_tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($tag); ?> -
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </h2>

                                             <ul>
                                               <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <?php if( $plan->en_tags): ?>
                                                  <li>
                                                    (<?php echo e($plan->group->admin()->name); ?>

                                                    <?php echo e($plan->group->admin()->family); ?>)
                                                    (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                                    <br>
                                                    <?php echo e($plan->en_tags); ?>

                                                    </li>
                                               <?php endif; ?>

                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.problem')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->problem); ?>

                                        </h2>

                                            <ul>
                                                <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php if( $plan->problem): ?>
                                                   <li>
                                                    (<?php echo e($plan->group->admin()->name); ?>

                                                    <?php echo e($plan->group->admin()->family); ?>)
                                                    (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                                    <br>
                                                    <?php echo e($plan->problem); ?>

                                                    </li>
                                               <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.question')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->question); ?>

                                        </h2>
                                      <ul>
                                        <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $plan->question): ?>
                                        <li>
                                         (<?php echo e($plan->group->admin()->name); ?>

                                         <?php echo e($plan->group->admin()->family); ?>)
                                         (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                         <br>
                                         <?php echo e($plan->question); ?>

                                         </li>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </ul>
                                </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.necessity')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->necessity); ?>

                                        </h2>
                                      <ul>
                                        <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $plan->necessity): ?>
                                        <li>
                                         (<?php echo e($plan->group->admin()->name); ?>

                                         <?php echo e($plan->group->admin()->family); ?>)
                                         (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                         <br>
                                         <?php echo e($plan->necessity); ?>

                                         </li>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.sub_question')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->sub_question); ?>

                                        </h2>

                                        <ul>
                                            <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $plan->sub_question): ?>
                                            <li>
                                             (<?php echo e($plan->group->admin()->name); ?>

                                             <?php echo e($plan->group->admin()->family); ?>)
                                             (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                             <br>
                                             <?php echo e($plan->sub_question); ?>

                                             </li>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.hypo')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->hypo); ?>

                                        </h2>

                                     <ul>
                                        <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $plan->hypo): ?>
                                        <li>
                                         (<?php echo e($plan->group->admin()->name); ?>

                                         <?php echo e($plan->group->admin()->family); ?>)
                                         (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                         <br>
                                         <?php echo e($plan->hypo); ?>

                                         </li>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.theory')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->theory); ?>

                                        </h2>

                                       <ul>
                                        <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $plan->theory): ?>
                                        <li>
                                         (<?php echo e($plan->group->admin()->name); ?>

                                         <?php echo e($plan->group->admin()->family); ?>)
                                         (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                         <br>
                                         <?php echo e($plan->theory); ?>

                                         </li>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.structure')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->structure); ?>

                                        </h2>

                                       <ul>
                                        <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $plan->structure): ?>
                                        <li>
                                         (<?php echo e($plan->group->admin()->name); ?>

                                         <?php echo e($plan->group->admin()->family); ?>)
                                         (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                         <br>
                                         <?php echo e($plan->structure); ?>

                                         </li>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.method')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->method); ?>

                                        </h2>

                                          <ul>
                                            <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $plan->method): ?>
                                            <li>
                                             (<?php echo e($plan->group->admin()->name); ?>

                                             <?php echo e($plan->group->admin()->family); ?>)
                                             (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                             <br>
                                             <?php echo e($plan->method); ?>

                                             </li>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </ul>
                                    </div>
                                </div>
                                <div class="col-xl-6 par">
                                    <div class="form-group fv-plugins-icon-container">
                                        <label>
                                            <?php echo e(__('sentences.source')); ?>

                                        </label>
                                        <h2>
                                            <?php echo e($main_plan->source); ?>

                                        </h2>

                                           <ul>
                                            <?php $__currentLoopData = $all_plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $plan->source): ?>
                                            <li>
                                             (<?php echo e($plan->group->admin()->name); ?>

                                             <?php echo e($plan->group->admin()->family); ?>)
                                             (<?php echo e(Morilog\Jalali\Jalalian::forge($plan->created_at)->format('d-m-Y')); ?>)
                                             <br>
                                             <?php echo e($plan->source); ?>

                                             </li>
                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </ul>
                                    </div>
                                </div>








                            </div>
                         </div>
                     </div>

                     <?php endif; ?>



                    <?php endif; ?>

                </div>
                <!--end::Content-->
            </div>

        </div>
        <!--end::Container-->
    </div>
</div>
<?php /**PATH G:\laravelProject\adyan\resources\views/admin/agent/profile_info.blade.php ENDPATH**/ ?>