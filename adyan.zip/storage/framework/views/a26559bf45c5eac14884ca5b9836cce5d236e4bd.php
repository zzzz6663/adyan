<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <div class="card-body p-0">
                    <!--begin::ویزارد-->
                    <div class="wizard wizard-1" id="kt_wizard_v1" data-wizard-state="step-first"
                        data-wizard-clickable="false">

                        <?php echo $__env->make('sections.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <form class="form" action="<?php echo e(route('curt.update',$curt->id)); ?>" id="kt_form" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                                <div class="col-xl-12 col-xxl-7">
                                    <!--begin::ویزارد Form-->
                                    <h1>
                                        فرم ویرایش طرح اجمالی
                                    </h1>
                                    <br>
                                    <br>
                                    <!--begin::ویزارد گام 1-->
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>  <?php echo e(__('sentences.title')); ?>   </label>
                                                <input type="text" value="<?php echo e(old('title',$curt->title)); ?>" class="form-control"
                                                    name="title" placeholder="   <?php echo e(__('sentences.title')); ?>   ">
                                                    <span class="form-text text-muted">
                                                        <?php echo e(__('sentences.enter_title')); ?>

                                                    </span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6">
                                            <!--begin::ورودی-->
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>       <?php echo e(__('sentences.tags')); ?>  : </label>
                                                
                                                <span class="content"><?php echo e(implode(' ,',$curt->tags()->pluck('tag')->toArray())); ?></span>

                                            </div>
                                            <!--end::ورودی-->
                                        </div>


                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>    <?php echo e(__('sentences.problem')); ?>     </label>
                                                <textarea class="form-control" name="problem"
                                                    rows="3"><?php echo e(old('problem',$curt->problem)); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>     <?php echo e(__('sentences.question')); ?>  </label>
                                                <textarea class="form-control" name="question"
                                                    rows="3"><?php echo e(old('question',$curt->question)); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>    <?php echo e(__('sentences.necessity')); ?>         </label>
                                                <textarea class="form-control" name="necessity"
                                                    rows="3"><?php echo e(old('necessity',$curt->necessity)); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>     <?php echo e(__('sentences.innovation')); ?>    </label>
                                                <textarea class="form-control" name="innovation"
                                                    rows="3"><?php echo e(old('innovation',$curt->innovation)); ?></textarea>
                                            </div>
                                        </div>
                                        <?php if($curt->history): ?>

                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>     <?php echo e(__('sentences.history')); ?>    </label>
                                                <?php echo e($curt->history); ?>

                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($curt->history): ?>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>     <?php echo e(__('sentences.fail_reason')); ?>    </label>
                                                <?php echo e($curt->fail_reason); ?>

                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <!--begin::ویزارد اقدامات-->
                                        <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                            
                                            <div>
                                                <input type="submit" value="    <?php echo e(__('sentences.save')); ?>   "
                                                    class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                                <a class="btn btn-danger font-weight-bold text-uppercase px-9 py-4"
                                                    href="<?php echo e(route('user.note')); ?>"><?php echo e(__('sentences.back')); ?>  </a>


                                            </div>
                                        </div>

                                        <div class="col-xl-12">
                                            <div class="form-group fv-plugins-icon-container">
                                                <ul class="history">
                                                    <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        (<?php echo e($curt->operator_curts()->name); ?>

                                                        <?php echo e($curt->operator_curts()->family); ?>)
                                                        (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                                        <br>
                                                        <span class="ti">
                                                            <?php echo e(__('sentences.title')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->title); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            <?php echo e(__('sentences.tags')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->tag); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            <?php echo e(__('sentences.problem')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->problem); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            <?php echo e(__('sentences.question')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->question); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            <?php echo e(__('sentences.necessity')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->necessity); ?>


                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            <?php echo e(__('sentences.innovation')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->innovation); ?>

                                                        </span>

                                                        <br>
                                                        <span class="ti">
                                                            <?php echo e(__('sentences.history')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->history); ?>

                                                        </span>

                                                        <br>
                                                        <span class="ti">
                                                            <?php echo e(__('sentences.fail_reason')); ?>

                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->fail_reason); ?>

                                                        </span>

                                                        <br>

                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>


                                    </div>

                                    <!--end::ویزارد گام 1-->


                                </div>
                            </div>

                            <!--end::ویزارد اقدامات-->
                        </form>


                        <!--end::ویزارد Form-->
                    </div>
                </div>
                <!--end::ویزارد Body-->
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/curt/edit.blade.php ENDPATH**/ ?>