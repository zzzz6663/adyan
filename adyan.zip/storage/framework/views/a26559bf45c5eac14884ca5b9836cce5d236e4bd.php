<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <div class="card-body p-0">
                    <!--begin::ویزارد-->
                    <div class="wizard wizard-1" id="kt_wizard_v1" data-wizard-state="step-first"
                        data-wizard-clickable="false">

                        <?php echo $__env->make('sections.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <form class="form" action="<?php echo e(route('curt.update',$curt->id)); ?>" id="kt_form" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                                <div class="col-xl-12 col-xxl-7">
                                    <!--begin::ویزارد Form-->
                                    <h1>
                                        فرم تعریف طرح اجمالی
                                    </h1>
                                    <br>
                                    <br>
                                    <!--begin::ویزارد گام 1-->
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label> عنوان </label>
                                                <input type="text" value="<?php echo e(old('title',$curt->title)); ?>" class="form-control"
                                                    name="title" placeholder="  عنوان ">
                                                <span class="form-text text-muted">لطفا عنوان خود را وارد
                                                    کنید.</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6">
                                            <!--begin::ورودی-->
                                            <div class="form-group fv-plugins-icon-container">
                                                <label> کلمات کلیدی </label>
                                                <div class="input-group">
                                                    <input type="text" id="ex_p" class="form-control"
                                                        placeholder="جستجو ...">
                                                    <div class="input-group-append">
                                                        <button class="btn btn-secondary" id="add_ex1"
                                                            type="button">اضافه کردن</button>
                                                    </div>
                                                </div>
                                                <div class="fv-plugins-message-container" id="tags">
                                                    

                                                    <?php $__currentLoopData = old('tags',explode('_',$curt->tags)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span type="button" class="btn self btn-outline-success mr-2">
                                                        <?php echo e($tag); ?>

                                                        <input type="text" name="tags[]" hidden="" value="<?php echo e($tag); ?>">
                                                    </span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <!--end::ورودی-->
                                        </div>


                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label> بیان مساله </label>
                                                <textarea class="form-control" name="problem"
                                                    rows="3"><?php echo e(old('problem',$curt->problem)); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label> سوال اصلی </label>
                                                <textarea class="form-control" name="question"
                                                    rows="3"><?php echo e(old('question',$curt->question)); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label> ضرورت </label>
                                                <textarea class="form-control" name="necessity"
                                                    rows="3"><?php echo e(old('necessity',$curt->necessity)); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label> جنبه نوآوری </label>
                                                <textarea class="form-control" name="innovation"
                                                    rows="3"><?php echo e(old('innovation',$curt->innovation)); ?></textarea>
                                            </div>
                                        </div>

                                        <!--begin::ویزارد اقدامات-->
                                        <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                            
                                            <div>
                                                <input type="submit" value="  دخیره   "
                                                    class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                                <a class="btn btn-danger font-weight-bold text-uppercase px-9 py-4"
                                                    href="<?php echo e(route('user.note')); ?>">برکشت</a>


                                            </div>
                                        </div>

                                        <div class="col-xl-12">
                                            <div class="form-group fv-plugins-icon-container">
                                                <ul class="history">
                                                    <?php $__currentLoopData = $all_curts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        (<?php echo e($curt->operator_curts()->name); ?>

                                                        <?php echo e($curt->operator_curts()->family); ?>)
                                                        (<?php echo e(Morilog\Jalali\Jalalian::forge($curt->created_at)->format('d-m-Y')); ?>)
                                                        <br>
                                                        <span class="ti">
                                                            عنوان:
                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->title); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            کلمات کلیدی:
                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->tags); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            بیان مساله :
                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->problem); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            سوال اصلی :
                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->question); ?>

                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            ضروریات:
                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->necessity); ?>


                                                        </span>
                                                        <br>


                                                        <span class="ti">
                                                            جنبه نوآوری:
                                                        </span>
                                                        <span class="cont">
                                                            <?php echo e($curt->innovation); ?>

                                                        </span>

                                                        <br>

                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>


                                    </div>

                                    <!--end::ویزارد گام 1-->


                                </div>
                            </div>

                            <!--end::ویزارد اقدامات-->
                        </form>


                        <!--end::ویزارد Form-->
                    </div>
                </div>
                <!--end::ویزارد Body-->
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/curt/edit.blade.php ENDPATH**/ ?>