<?php ($side = true); ?>
<?php ($header = true); ?>
<?php ($footer = true); ?>


<?php $__env->startSection('main'); ?>
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">


            <!--begin::Card-->
            <div class="card card-custom">
                <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title">
                        <h3 class="card-label">

                        </h3>
                    </div>
                    <div class="card-toolbar">

                    </div>
                </div>

                <div class="card-body ">

                    <h2>
                            <?php echo e($news->title); ?>

                        <span class="text-muted pt-2 font-size-sm d-"><?php echo e(Morilog\Jalali\Jalalian::forge($news->created_at)->format('d-m-Y')); ?>

                        </span>
                    </h2>
                    <p>
                        <?php echo e($news->content); ?>

                    </p>
                    <a href="<?php echo e(route('news.list')); ?>" class="btn btn-primary"><?php echo e(__('sentences.back')); ?></a>
                </div>
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/news/single_news.blade.php ENDPATH**/ ?>