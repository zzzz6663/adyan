<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <div class="row">
                    <div class="col-xl-6">
                        <!--begin::Card-->
                        <div class="card card-custom card-stretch" id="kt_todo_list">


                            <!--begin::Body-->
                            <div class="card-body p-0">
                                <!--begin::Responsive container-->
                                <div class="table-responsive">
                                    <?php $__currentLoopData = $duties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list list-hover min-w-500px" data-inbox="list">
                                        <div class="d-flex align-items-start list-item card-spacer-x py-4"
                                            data-inbox="message">

                                            <!--begin::Info-->
                                            <div class="flex-grow-1 mt-1 mr-2" data-toggle="view">
                                                <!--begin::Title-->
                                                <div class="font-weight-bolder mr-2">
                                                        <?php switch( $duty->type):
                                                            case ('register'): ?>
                                                            دانشجو
                                                                <?php break; ?>
                                                            <?php default: ?>

                                                        <?php endswitch; ?>


                                                </div>
                                                <!--end::Title-->
                                            </div>
                                            <!--end::Info-->

                                            <!--begin::Details-->
                                            <div class="d-flex align-items-center justify-content-end flex-wrap"
                                                data-toggle="view">
                                                <!--begin::تاریخtime-->
                                                <div class="font-weight-bolder" data-toggle="view">
                                                    روز قبل
                                                </div>
                                                <!--end::تاریخtime-->

                                                <!--begin::User تصویر-->
                                                <div class="symbol symbol-light-danger symbol-30 ml-3">

                                                </div>
                                                <!--end::User تصویر-->
                                            </div>
                                            <!--end::Details-->
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                                <!--end::Responsive container-->

                                
                            </div>
                            <!--end::Body-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <div class="col-xl-6 pt-10 pt-xl-0">
                        <div class="card card-custom gutter-b">
                            <div class="card-header">
                                <div class="card-title">
                                    <h3 class="card-label">  اخرین گزارشات </h3>
                                </div>
                            </div>
                            <div class="card-body">
                                <!--begin::نمونه-->
                                <div class="example example-basic">
                                    <div class="example-preview">
                                        <!--begin::تایم لاین-->
                                        <div class="timeline timeline-3">
                                            <div class="timeline-items">
                                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="timeline-item">
                                                    <div class="timeline-media">
                                                        <?php switch($log->type):
                                                            case ('register'): ?>

                                                            <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                                <?php break; ?>

                                                            <?php default: ?>

                                                        <?php endswitch; ?>

                                                    </div>
                                                    <div class="timeline-content">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between mb-3">
                                                            <div class="mr-2">
                                                                <?php switch($log->type):
                                                                case ('register'): ?>
                                                                <a href="#" class="text-dark-75 text-hover-primary font-weight-bold">
                                                                    ثبت نام
                                                                </a>
                                                                    <?php break; ?>

                                                                <?php default: ?>

                                                            <?php endswitch; ?>

                                                                <span class="text-muted ml-2">
                                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($log->created_at)->format('d-m-Y')); ?>

                                                                </span>
                                                                
                                                            </div>

                                                        </div>
                                                        <p class="p-0">
                                                         <?php switch($log->type):
                                                             case ('register'): ?>
                                                             دانشجو
                                                             <?php echo e($log->student()->name); ?>

                                                             <?php echo e($log->student()->family); ?>

                                                             ثبت نام کردند
                                                                 <?php break; ?>

                                                             <?php default: ?>

                                                         <?php endswitch; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </div>
                                        </div>
                                        <!--end::تایم لاین-->
                                    </div>
                                </div>
                                <!--end::نمونه-->


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/home/note.blade.php ENDPATH**/ ?>