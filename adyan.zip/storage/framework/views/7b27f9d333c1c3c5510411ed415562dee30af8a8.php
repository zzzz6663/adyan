<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <div class="row">
                    <div class="col-xl-6">
                        <!--begin::Card-->


                        <div class="card card-custom card-stretch" id="kt_todo_list">

                            <div class="card-header">
                                <div class="card-title">
                                    <h3 class="card-label"> اخرین تسک ها </h3>
                                </div>
                            </div>
                            <!--begin::Body-->
                            <div class="card-body p-0">
                                <!--begin::Responsive container-->
                                <div class="table-responsive">
                                    <?php $__currentLoopData = $duties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list list-hover min-w-500px" data-inbox="list">
                                        <div class="d-flex align-items-start list-item card-spacer-x py-4"
                                            data-inbox="message">

                                            <!--begin::Info-->
                                            <div class="flex-grow-1 mt-1 mr-2" data-toggle="view">
                                                <!--begin::Title-->
                                                <div class="font-weight-bolder mr-2">
                                                    <?php switch( $duty->type):

                                                    case ('register'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('expert')): ?>
                                                    تایید ثبت نام دانشجو
                                                    <?php echo e($duty->student()->name); ?>

                                                    <?php echo e($duty->student()->family); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('submit_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                    ثبت  طرح اجمالی اجمالی

                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('verify_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('expert|master')): ?>
                                                    بررسی  طرح اجمالی اجمالی
                                                    دانشجو
                                                    <?php echo e($duty->curt->user->name); ?>

                                                    <?php echo e($duty->curt->user->family); ?>


                                                    <?php endif; ?>
                                                    <?php break; ?>




                                                    <?php case ('edit_curt_by_student'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                ویرایش  طرح اجمالی اجمالی  به خواسته
                                                کارشناس
                                                <?php echo e($duty->operator()->name); ?>

                                                <?php echo e($duty->operator()->family); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('save_curt_group_by_expert'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                    کارشناس
                                                    <?php echo e($duty->operator()->name); ?>

                                                    <?php echo e($duty->operator()->family); ?>

                                                     طرح اجمالی را به گروه
                                                <?php echo e($duty->curt->group->name); ?>

                                                ارجاع داد
                                                    <?php endif; ?>
                                                    <?php break; ?>



                                                    



                                                    <?php case ('review_curt_by_master'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  اصلاح  طرح اجمالی توسط دانشجو
                                                  <?php echo e($duty->student()->name); ?>

                                                  <?php echo e($duty->student()->family); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>
















                                                    <?php default: ?>


                                                    <?php endswitch; ?>


                                                </div>
                                                <!--end::Title-->
                                            </div>
                                            <!--end::Info-->

                                            <!--begin::Details-->
                                            <div class="d-flex align-items-center justify-content-end flex-wrap"
                                                data-toggle="view">
                                                <!--begin::تاریخtime-->
                                                <div class="font-weight-bolder alert <?php echo e($duty->down_id?'alert-success':'alert-danger'); ?>"
                                                    data-toggle="view">



                                                    <?php switch( $duty->type):

                                                    case ('register'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('expert')): ?>
                                                    <?php if($duty->operator_id): ?>
                                                    انجام شده توسط
                                                    کارشناس
                                                    <?php echo e($duty->operator()->name); ?>

                                                    <?php echo e($duty->operator()->family); ?>

                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($duty->time)->ago()); ?>

                                                    <?php else: ?>
                                                    درخواست شده
                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($duty->created_at)->ago()); ?>

                                                    <a class="btn btn-primary"
                                                        href="<?php echo e(route('admin.verify.student',[$duty->student()->id,$duty->id])); ?>">تایید
                                                        حساب</a>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('submit_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                    <?php if($duty->time): ?>
                                                    <span class="alert alert-info">
                                                     انجام شده در
                                                     <?php echo e(Morilog\Jalali\Jalalian::forge($duty->time)->ago()); ?>

                                                    </span>
                                                    <?php else: ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('curt.create')); ?>">تبت  طرح اجمالی
                                                        اجمالی
                                                        حساب</a>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('verify_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master|expert')): ?>
                                                    <?php if($duty->time): ?>
                                                    <span class="alert alert-info">
                                                     انجام شده در
                                                     <?php echo e(Morilog\Jalali\Jalalian::forge($duty->time)->ago()); ?>

                                                    </span>
                                                    <?php else: ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('admin.show.curt',$duty->curt->id)); ?>">
                                                        بررسی  طرح اجمالی اجمالی
                                                        <?php echo e($duty->curt->title); ?>

                                            </a>
                                                    <?php endif; ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>



                                                    <?php case ('edit_curt_by_student'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                    <?php if($duty->time): ?>
                                                    ویرایش شده در
                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($duty->time)->ago()); ?>

                                                    <?php else: ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('curt.edit',$duty->curt->id)); ?>">
                                                        ویرایش
                                                    </a>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php break; ?>



                                                    <?php case ('save_curt_group_by_expert'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('curt.edit',$duty->curt->id)); ?>">
                                                        ویرایش
                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>




                                                    <?php case ('review_curt_by_master'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>


                                                    <?php if($duty->time): ?>
                                                    ویرایش شده در
                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($duty->time)->ago()); ?>

                                                    <?php else: ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('session.create')); ?>">
                                                        تعین جلسه
                                                    </a>

                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php break; ?>






                                                    <?php default: ?>

                                                    <?php endswitch; ?>

                                                </div>
                                                <!--end::تاریخtime-->

                                                <!--begin::User تصویر-->
                                                <div class="symbol symbol-light-danger symbol-30 ml-3">

                                                </div>
                                                <!--end::User تصویر-->
                                            </div>
                                            <!--end::Details-->
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                                <!--end::Responsive container-->

                                
                            </div>
                            <!--end::Body-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <div class="col-xl-6 pt-10 pt-xl-0">
                        <div class="card card-custom gutter-b">
                            <div class="card-header">
                                <div class="card-title">
                                    <h3 class="card-label"> اخرین گزارشات </h3>
                                </div>
                            </div>
                            <div class="card-body">
                                <!--begin::نمونه-->
                                <div class="example example-basic">
                                    <div class="example-preview">
                                        <!--begin::تایم لاین-->
                                        <div class="timeline timeline-3">
                                            <div class="timeline-items">
                                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="timeline-item">
                                                    <div class="timeline-media">
                                                        <?php switch($log->type):
                                                        case ('register'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('verify'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('submit_curt'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('edit_curt_by_student'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('save_curt_group_by_expert'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('review_curt_by_master'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('select_curt_master'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('accept_curt'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php default: ?>

                                                        <?php endswitch; ?>


                                                    </div>
                                                    <div class="timeline-content">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between mb-3">
                                                            <div class="mr-2">
                                                                <?php switch($log->type):
                                                                case ('register'): ?>
                                                                <span class="">
                                                                    ثبت نام
                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('verify'): ?>
                                                                <span class="">
                                                                      بررسی ثبت نام
                                                                </span>
                                                                <?php break; ?>
                                                                <?php case ('submit_curt'): ?>
                                                                <span class="">
                                                                          ثبت  طرح اجمالی توسط دانشجو
                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('edit_curt_by_student'): ?>
                                                                <span class="">
                                                               بررسی  طرح اجمالی توسط دانشجو
                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('save_curt_group_by_expert'): ?>
                                                                <span class="">
                                                                     ارجاع  طرح اجمالی  به گروه
                                                                </span>
                                                                <?php break; ?>



                                                                <?php case ('review_curt_by_master'): ?>
                                                                <span class="">
                                                                     ارجاع مجدد  طرح اجمالی  به گروه
                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('select_curt_master'): ?>
                                                                <span class="">
                                                                   انتخاب استاد راهنما
                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('accept_curt'): ?>
                                                                <span class="">
                                                                تایید طرح اجمالی
                                                                </span>
                                                                <?php break; ?>

                                                                <?php default: ?>

                                                                <?php endswitch; ?>

                                                                <span class="text-muted ml-2">
                                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($log->created_at)->format('d-m-Y')); ?>

                                                                </span>
                                                                

                                                            </div>

                                                        </div>
                                                        <p class="p-0">
                                                            <?php switch($log->type):
                                                            case ('register'): ?>
                                                            <span class="alert alert-success">
                                                                دانشجو
                                                                <?php echo e($log->student()->name); ?>

                                                                <?php echo e($log->student()->family); ?>

                                                                ثبت نام کردند
                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('verify'): ?>
                                                            <span class="alert alert-success">
                                                                حساب
                                                                دانشجو
                                                                <?php echo e($log->student()->name); ?>

                                                                <?php echo e($log->student()->family); ?>

                                                                توسط متخصص
                                                                <?php echo e($log->operator()->name); ?>

                                                                <?php echo e($log->operator()->family); ?>

                                                                تایید شد
                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('submit_curt'): ?>
                                                            <span class="alert alert-success">
                                                                     طرح اجمالی   اجمالی توسط دانشجو

                                                                <?php echo e($log->student()->name); ?>

                                                                <?php echo e($log->student()->family); ?>

                                                                ثبت شد
                                                            </span>
                                                            <?php break; ?>



                                                            <?php case ('edit_curt_by_student'): ?>
                                                            <span class="alert alert-success">
                                                                کارشناس
                                                                <?php echo e($log->operator()->name); ?>

                                                                <?php echo e($log->operator()->family); ?>

                                                                 درخواست اصلاح در  طرح اجمالی اجمالی  را داشته است

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('save_curt_group_by_expert'): ?>
                                                            <span class="alert alert-success">
                                                                کارشناس
                                                                <?php echo e($log->operator()->name); ?>

                                                                <?php echo e($log->operator()->family); ?>

                                                                 طرح اجمالی را به گروه

                                                            <?php echo e($log->curt->group->name); ?>

                                                            ارجاع داد

                                                            </span>
                                                            <?php break; ?>



                                                            <?php case ('review_curt_by_master'): ?>
                                                            <span class="alert alert-success">
                                                                دانشجو

                                                                <?php echo e($log->student()->name); ?>

                                                                <?php echo e($log->student()->family); ?>

                                                                طرح اجمالی را برای بررسی بیشتر به گروه

                                                            <?php echo e($log->curt->group->name); ?>

                                                            ارجاع داد

                                                            </span>
                                                            <?php break; ?>



                                                            <?php case ('select_curt_master'): ?>
                                                            <span class="alert alert-success">
                                                                 استاد
                                                                 <?php echo e($log->curt->master()->name); ?>

                                                                 <?php echo e($log->curt->master()->family); ?>

                                                                 به عنوان
                                                                 استاد راهنمای  طرح اجمالی


                                                            <?php echo e($log->curt->group->name); ?>

                                                          انتخاب  شد

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('accept_curt'): ?>
                                                            <span class="alert alert-success">
                                                             گروه
                                                            <?php echo e($log->curt->group->name); ?>

                                                            طرح اجمالی دانشجو

                                                            <?php echo e($log->student()->name); ?>

                                                            <?php echo e($log->student()->family); ?>

                                                            را تایید کردند
                                                            </span>
                                                            <?php break; ?>











                                                            <?php default: ?>

                                                            <?php endswitch; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </div>
                                        </div>
                                        <!--end::تایم لاین-->
                                    </div>
                                </div>
                                <!--end::نمونه-->


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/home/note.blade.php ENDPATH**/ ?>