<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
            <?php echo $__env->make('student.progress',['status'=>auth()->user()->status], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="card card-custom">
                <div class="row">
                    <div class="col-xl-6">
                        <!--begin::Card-->


                        <div class="card card-custom card-stretch" id="kt_todo_list">

                            <div class="card-header">
                                <div class="card-title">
                                    <h3 class="card-label">
                                        <?php echo e(__('sentences.last_duty')); ?>


                                         </h3>
                                </div>
                            </div>
                            <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                            <?php if(auth()->user()->curt() && !auth()->user()->curt()->group_id && auth()->user()->status == 'curt' && auth()->user()->direct): ?>

                            <form action="<?php echo e(route('student.subject.list')); ?>" method="post">
                               <?php echo csrf_field(); ?>
                               <?php echo method_field('post'); ?>
                               <input type="submit" class="btn btn-success" value=" <?php echo e(__('sentences.select_subject')); ?> ">

                              </a>
                           </form>
                           <?php endif; ?>
                           <?php endif; ?>

                            <!--begin::Body-->
                            <div class="card-body p-0">
                                <!--begin::Responsive container-->
                                <div class="table-responsive">
                                    <?php $__currentLoopData = $duties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="list list-hover min-w-500px" data-inbox="list">
                                        <div class="d-flex align-items-start list-item card-spacer-x py-4"
                                            data-inbox="message">

                                            <!--begin::Info-->
                                            <div class="flex-grow-1 mt-1 mr-2" data-toggle="view">
                                                <!--begin::Title-->
                                                <div class="font-weight-bolder mr-2">
                                                    <?php switch( $duty->type):

                                                    case ('register'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('expert')): ?>

                                                    <?php echo e(__('sentences.confirm_student_confirm')); ?>

                                                    <?php echo e($duty->student()->name); ?>

                                                    <?php echo e($duty->student()->family); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('student_go_quiz'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                      <?php echo e(__('sentences.participating_in_a_test')); ?>


                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('submit_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                    <?php echo e(__('sentences.submit_curt')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('verify_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('expert|master')): ?>
                                                    <?php echo e(__('sentences.vrify_curt')); ?>

                                                    <?php echo e($duty->curt->user->name); ?>

                                                    <?php echo e($duty->curt->user->family); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>




                                                    <?php case ('edit_curt_by_student'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>

                                                <?php echo e(__('sentences.request_vrify_curt')); ?>

                                                <?php echo e($duty->operator()->name); ?>

                                                <?php echo e($duty->operator()->family); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('save_curt_group_by_expert'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                    
                                                    <?php echo e(__('sentences.pass_curt_to_group',['expert'=>$duty->operator()->name.' '.$duty->operator()->family,'group'=>$duty->curt->group->name])); ?>

                                                    
                                                    <?php endif; ?>
                                                    <?php break; ?>







                                                    <?php case ('review_curt_by_master'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>

                                                  <?php echo e(__('sentences.review_curt_by_master')); ?>

                                                  <?php echo e($duty->student()->name); ?>

                                                  <?php echo e($duty->student()->family); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('submit_plan'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                  <?php echo e(__('sentences.submit_plan')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('edit_plan_by_student'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                  <?php echo e(__('sentences.edit_plan_by_student_duty')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('submit_survey'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  <?php echo e(__('sentences.submit_survey_duty')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>
                                                    <?php case ('confirm_session'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  <?php echo e(__('sentences.confirm_session_duty')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('define_guid'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  <?php echo e(__('sentences.define_guid_title')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>
                                                    <?php case ('verify_plan'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  <?php echo e(__('sentences.verify_plan')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('verify_plan'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  <?php echo e(__('sentences.verify_plan_by_master')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('verify_plan_by_master'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  <?php echo e(__('sentences.verify_plan_by_master')); ?>

                                                    <?php endif; ?>
                                                    <?php break; ?>
















                                                    <?php default: ?>


                                                    <?php endswitch; ?>


                                                </div>
                                                <!--end::Title-->
                                            </div>
                                            <!--end::Info-->

                                            <!--begin::Details-->
                                            <div class="d-flex align-items-center justify-content-end flex-wrap"
                                                data-toggle="view">
                                                <!--begin::تاریخtime-->
                                                <div class="font-weight-bolder "
                                                    data-toggle="view">


                                                        <?php echo e($duty->type); ?>

                                                    <?php switch( $duty->type):

                                                    case ('register'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('expert')): ?>
                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($duty->created_at)->ago()); ?>

                                                    <a class="btn btn-primary"
                                                        href="<?php echo e(route('admin.see.profile.verify.student',[$duty->student()->id,$duty->id])); ?>">
                                                        <?php echo e(__('sentences.see_profile')); ?>

                                                    </a>
                                                    
                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('student_go_quiz'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>

                                                    <a class="btn btn-primary" href="<?php echo e(route('student.per.quiz')); ?>">
                                                        
                                                        <?php echo e(__('sentences.action')); ?>

                                                         </a>
                                                            <?php if(!$user->check_quiz_pass() && $user->quizzes()->count()>0): ?>

                                                            <?php echo e(__('sentences.day_remain_to_quiz', ['time'=> $user->persian_latest_falid_quiz() ])); ?>

                                                            <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('submit_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('student.per.curt')); ?>">
                                                        <?php echo e(__('sentences.submit_curt')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('verify_curt'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('expert')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('admin.show.curt',$duty->curt->id)); ?>">
                                                        <?php echo e(__('sentences.verify_curt')); ?>

                                                        
                                                     </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>



                                                    <?php case ('edit_curt_by_student'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('curt.edit',$duty->curt->id)); ?>">
                                                        <?php echo e(__('sentences.edit')); ?>

                                                    </a>



                                                    <?php endif; ?>
                                                    <?php break; ?>



                                                    <?php case ('save_curt_group_by_expert'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('curt.edit',$duty->curt->id)); ?>">
                                                        <?php echo e(__('sentences.edit')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>




                                                    <?php case ('review_curt_by_master'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('session.create')); ?>">
                                                        
                                                        <?php echo e(__('sentences.create_session')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>


                                                    <?php case ('verify_subject'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                   <a class="btn btn-primary" href="<?php echo e(route('session.create',['group'=>$duty->group->id])); ?>">
                                                        
                                                        <?php echo e(__('sentences.create_session')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('submit_plan'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                   <a class="btn btn-primary" href="<?php echo e(route('plan.create')); ?>">
                                                        <?php echo e(__('sentences.submit_plan')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('verify_plan'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                   <a class="btn btn-primary" href="<?php echo e(route('session.create',['plan'=>$duty->plan->id])); ?>">
                                                        
                                                        <?php echo e(__('sentences.create_session')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>
                                                    <?php case ('verify_plan_by_master'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                   
                                                        
                                                        
                                                    
                                                    <a class="btn btn-outline-primary"
                                                    href="<?php echo e(route('admin.show.plan',[ $duty->plan->id])); ?>">
                                                    <?php echo e(__('sentences.verify')); ?> </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('edit_plan_by_student'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('student')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('plan.edit',['plan'=>$duty->plan->id])); ?>">
                                                        
                                                        <?php echo e(__('sentences.action')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>




                                                    <?php case ('submit_survey'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                  <a class="btn btn-primary" href="<?php echo e(route('survey.edit',[$duty->survey->id])); ?>">
                                                    <?php echo e(__('sentences.submit_survey_master')); ?>

                                                </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('confirm_session'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                     <a class="btn btn-primary" href="<?php echo e(route('session.confirm.show',[$duty->session->id])); ?>">
                                                        <?php echo e(__('sentences.confirm_session')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>

                                                    <?php case ('define_guid'): ?>
                                                    <?php if(auth()->check() && auth()->user()->hasRole('master')): ?>
                                                    
                                                     <a class="btn btn-primary" href="<?php echo e(route('admin.define.guid',$duty->curt->id)); ?>">
                                                        <?php echo e(__('sentences.select')); ?>

                                                    </a>
                                                    <?php endif; ?>
                                                    <?php break; ?>




                                                    <?php default: ?>

                                                    <?php endswitch; ?>

                                                </div>
                                                <!--end::تاریخtime-->

                                                <!--begin::User تصویر-->
                                                <div class="symbol symbol-light-danger symbol-30 ml-3">

                                                </div>
                                                <!--end::User تصویر-->
                                            </div>
                                            <!--end::Details-->
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                                <!--end::Responsive container-->

                                
                            </div>
                            <!--end::Body-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <div class="col-xl-6 pt-10 pt-xl-0">
                        <div class="card card-custom gutter-b">
                            <div class="card-header">
                                <div class="card-title">
                                    <h3 class="card-label">
                                        <?php echo e(__('sentences.last_logs')); ?>

                              </h3>
                                </div>
                            </div>
                            <div class="card-body">
                                <!--begin::نمونه-->
                                <div class="example example-basic">
                                    <div class="example-preview">
                                        <!--begin::تایم لاین-->
                                        <div class="timeline timeline-3">
                                            <div class="timeline-items">
                                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="timeline-item">
                                                    <div class="timeline-media">
                                                        <?php switch($log->type):
                                                        case ('register'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('verify'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('submit_curt'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('edit_curt_by_student'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('save_curt_group_by_expert'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('review_curt_by_master'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('select_curt_master'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('select_plan_guid'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('select_curt_guid'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('accept_curt'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>


                                                        <?php case ('pass_quiz'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('create_subject'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('subject_result'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>

                                                        <?php case ('submit_subject'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('submit_plan'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('submit_plan_master'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('edit_plan_by_student'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->group->admin()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('edit_plan_by_student_from_master'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('confirm_plan'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->operator()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('accept_plan'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->group->admin()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('submit_survey'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('answer_survey'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('verify_curt_by_expert'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>
                                                        <?php case ('accept_without_guid'): ?>
                                                        <img alt="Pic" src="<?php echo e($log->student()->avatar()); ?>">
                                                        <?php break; ?>


                                                        <?php default: ?>

                                                        <?php endswitch; ?>


                                                    </div>
                                                    <div class="timeline-content">
                                                        <div
                                                            class="d-flex align-items-center justify-content-between mb-3">
                                                            <div class="mr-2">
                                                                
                                                                <?php switch($log->type):
                                                                case ('register'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.register')); ?>

                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('verify'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.verify_regiter')); ?>


                                                                </span>
                                                                <?php break; ?>
                                                                <?php case ('submit_curt'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.create_curt')); ?>

                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('edit_curt_by_student'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.verify_curt_by_student')); ?>


                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('save_curt_group_by_expert'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.save_curt_group_by_expert')); ?>


                                                                </span>
                                                                <?php break; ?>



                                                                <?php case ('review_curt_by_master'): ?>
                                                                <span class="">

                                                                    <?php echo e(__('sentences.review_curt_by_master')); ?>


                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('select_curt_master'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.select_curt_master')); ?>


                                                                </span>
                                                                <?php break; ?>
                                                                <?php case ('select_plan_guid'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.select_plan_guid')); ?>


                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('select_curt_guid'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.select_curt_guid')); ?>


                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('accept_curt'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.accept_curt')); ?>


                                                                </span>
                                                                <?php break; ?>


                                                                <?php case ('pass_quiz'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.pass_quiz')); ?>

                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('create_subject'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.create_subject')); ?>

                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('subject_result'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.subject_result')); ?>

                                                                </span>
                                                                <?php break; ?>
                                                                <?php case ('submit_survey'): ?>
                                                                <span class="">
                                                                    <?php echo e(__('sentences.submit_survey_log__title')); ?>

                                                                </span>
                                                                <?php break; ?>

                                                                <?php case ('submit_subject'): ?>
                                                                <?php echo e(__('sentences.submit_subject_student_log')); ?>

                                                                 <?php break; ?>

                                                                <?php case ('submit_plan'): ?>
                                                                <?php echo e(__('sentences.submit_plan_student_log')); ?>

                                                                <?php break; ?>
                                                                <?php case ('submit_plan_master'): ?>
                                                                <?php echo e(__('sentences.submit_plan_student_log')); ?>

                                                                <?php break; ?>

                                                                <?php case ('edit_plan_by_student'): ?>
                                                                <?php echo e(__('sentences.edit_plan_by_student_log')); ?>

                                                                <?php break; ?>
                                                                <?php case ('edit_plan_by_student_from_master'): ?>
                                                                <?php echo e(__('sentences.edit_plan_by_student_log')); ?>

                                                                <?php break; ?>
                                                                <?php case ('confirm_plan'): ?>
                                                                <?php echo e(__('sentences.confirm_plan_title')); ?>

                                                                <?php break; ?>

                                                                <?php case ('accept_plan'): ?>
                                                                <?php echo e(__('sentences.accept_plan_student_log')); ?>

                                                                <?php break; ?>
                                                                <?php case ('answer_survey'): ?>
                                                                <?php echo e(__('sentences.answer_survey')); ?>

                                                                <?php break; ?>
                                                                <?php case ('verify_curt_by_expert'): ?>
                                                                <?php echo e(__('sentences.verify_curt_by_expert_log_title')); ?>

                                                                <?php break; ?>
                                                                <?php case ('accept_without_guid'): ?>
                                                                <?php echo e(__('sentences.accept_without_guid_title')); ?>

                                                                <?php break; ?>

                                                                <?php case ('pass_curt_to_group'): ?>
                                                                <?php echo e(__('sentences.pass_curt_to_group_title')); ?>

                                                                <?php break; ?>





















                                                                <?php default: ?>

                                                                <?php endswitch; ?>

                                                                <span class="text-muted ml-2">
                                                                    <?php echo e(Morilog\Jalali\Jalalian::forge($log->created_at)->format('d-m-Y')); ?>

                                                                </span>
                                                                

                                                            </div>

                                                        </div>
                                                        <p class="p-0" style="line-height: 2.5em">
                                                            <?php switch($log->type):
                                                            case ('register'): ?>
                                                            <span class="alert alert-success">
                                                                <?php echo e(__('sentences.register_student_logs',['name'=>$log->student()->name.' '.$log->student()->family])); ?>

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('verify'): ?>
                                                            <span class="alert alert-success">
                                                                <?php echo e(__('sentences.confirm_student_account_by_exprt',['name'=>$log->student()->name.' '.$log->student()->family,'expert'=>$log->operator()->name.' '.$log->operator()->family])); ?>

                                                            </span>
                                                            <?php break; ?>


                                                            <?php case ('submit_curt'): ?>
                                                            <span class="alert alert-success">
                                                                <?php echo e(__('sentences.submit_curt_by_student',['student'=>$log->student()->name.' '.$log->student()->family])); ?>

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('edit_curt_by_student'): ?>
                                                            <span class="alert alert-success">
                                                                <?php echo e(__('sentences.edit_curt_by_student',['expert'=>$log->operator()->name.' '.$log->operator()->family])); ?>

                                                            </span>
                                                            <?php break; ?>


                                                            <?php case ('save_curt_group_by_expert'): ?>
                                                            <span class="alert alert-success">
                                                            <?php echo e(__('sentences.save_curt_group_by_expert_log',['expert'=>$log->operator()->name.' '.$log->operator()->family,'group'=>$log->curt->group->name,'student'=>$log->curt->user->name.' '.$log->curt->user->family])); ?>

                                                            </span>
                                                            <?php break; ?>


                                                            <?php case ('review_curt_by_master'): ?>
                                                            <span class="alert alert-success">
                                                            <?php echo e(__('sentences.review_curt_by_master_by_student',['student'=>$log->operator()->name.' '.$log->operator()->family,'group'=>$log->curt->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>



                                                            <?php case ('select_curt_master'): ?>
                                                            <span class="alert alert-success">
                                                          <?php echo e(__('sentences.select_curt_master_for_curt',['master'=>$log->curt->master()->name.' '.$log->curt->master()->family,'group'=>$log->curt->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('select_plan_guid'): ?>
                                                            <span class="alert alert-success">
                                                          <?php echo e(__('sentences.select_plan_guid_for_plan',['master'=>$log->plan->master->name.' '.$log->plan->master->family,'group'=>$log->plan->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('select_curt_guid'): ?>
                                                            <span class="alert alert-success">
                                                          <?php echo e(__('sentences.select_curt_guid_for_curt',['master'=>$log->curt->master()->name.' '.$log->curt->master()->family,'group'=>$log->curt->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('accept_curt'): ?>
                                                            
                                                            <?php break; ?>


                                                            <?php case ('pass_quiz'): ?>
                                                            <span class="alert alert-success">
                                                            <?php echo e(__('sentences.pass_quiz_student',[ 'student'=>$log->student()->name.' '.$log->student()->family])); ?>

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('create_subject'): ?>
                                                            <span class="alert alert-success">
                                                            <?php echo e(__('sentences.create_subject_log',[ 'master'=>$log->student()->name.' '.$log->student()->family,'subject'=>$log->subject->title,'group'=>$log->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>


                                                            <?php case ('subject_result'): ?>
                                                            <span class="alert alert-success">
                                                            <?php echo e(__('sentences.subject_result_log',[ 'master'=>$log->student()->name.' '.$log->student()->family,'subject'=>$log->subject->title,'group'=>$log->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('submit_survey'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.survey_submit_log',[ 'master'=>$log->student()->name.' '.$log->student()->family,'name'=>$log->survey->name,])); ?>

                                                            </span>
                                                            <?php break; ?>





                                                            <?php case ('submit_subject'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.submit_subject_student',['subject'=>$log->subject->title,'master'=>$log->subject->master->name.' '.$log->subject->master->family,'student'=>$log->student()->name.' '.$log->student()->family])); ?>

                                                            </span>
                                                            <?php break; ?>




                                                            <?php case ('submit_plan'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.submit_plan_log',['student'=>$log->student()->name.' '.$log->student()->family,'group'=>$log->plan->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('submit_plan_master'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.submit_plan_master_log',['student'=>$log->student()->name.' '.$log->student()->family,'master'=>$log->operator()->name.' '.$log->operator()->family])); ?>

                                                            </span>
                                                            <?php break; ?>

                                                            <?php case ('edit_plan_by_student'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.edit_plan_by_student',['student'=>$log->student()->name.' '.$log->student()->family,'group'=>$log->plan->group->name ])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('edit_plan_by_student_from_master'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.edit_plan_by_student_from_master',['student'=>$log->student()->name.' '.$log->student()->family,'master'=>$log->operator()->name.' '.$log->operator()->family ])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('confirm_plan'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.confirm_plan _log',['student'=>$log->student()->name.' '.$log->student()->family,'master'=>$log->operator()->name.' '.$log->operator()->family ])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('accept_plan'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.accept_plan_log',['student'=>$log->student()->name.' '.$log->student()->family,'group'=>$log->plan->group->name ])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('answer_survey'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.answer_survey_log',['master'=>$log->student()->name.' '.$log->student()->family,'name'=>$log->survey->name ])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('accept_without_guid'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.accept_without_guid_title_log',['student'=>$log->student()->name.' '.$log->student()->family,'group'=>$log->curt->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>
                                                            <?php case ('pass_curt_to_group'): ?>
                                                            <span class="">
                                                                <?php echo e(__('sentences.pass_curt_to_group_log',['student'=>$log->student()->name.' '.$log->student()->family,'group'=>$log->curt->group->name])); ?>

                                                            </span>
                                                            <?php break; ?>






                                                            <?php default: ?>

                                                            <?php endswitch; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </div>
                                        </div>
                                        <!--end::تایم لاین-->
                                    </div>
                                </div>
                                <!--end::نمونه-->


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/home/note.blade.php ENDPATH**/ ?>