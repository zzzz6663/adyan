<?php $__env->startSection('main'); ?>
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom">
                <div class="card-body p-0">
                    <!--begin::ویزارد-->
                    <div class="wizard wizard-1" id="kt_wizard_v1" data-wizard-state="step-first"
                        data-wizard-clickable="false">

                        <?php echo $__env->make('sections.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <form class="form" action="<?php echo e(route('quiz.question.store',$quiz->id)); ?>" id="kt_form"
                            method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                                <div class="col-xl-12 col-xxl-7">
                                    <!--begin::ویزارد Form-->
                                        <h1>
                                            <?php echo e(__('sentences.new_question_form')); ?>


                                        </h1>
                                            <br>
                                            <br>
                                    <!--begin::ویزارد گام 1-->
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>    <?php echo e(__('sentences.question_title')); ?>    </label>
                                                <input type="text" value="<?php echo e(old('question')); ?>" class="form-control" name="question"
                                                    placeholder="   <?php echo e(__('sentences.question_title')); ?>  " >
                                                <span class="form-text text-muted">
                                                    <?php echo e(__('sentences.enter_question')); ?>

                                                </span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>            <?php echo e(__('sentences.a1')); ?>   </label>
                                                <input type="text" value="<?php echo e(old('a1')); ?>" class="form-control" name="a1"
                                                    placeholder="    <?php echo e(__('sentences.a1')); ?>  " >
                                                    <span class="form-text text-muted">
                                                        <?php echo e(__('sentences.enter_a1')); ?>

                                                    </span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>      <?php echo e(__('sentences.a2')); ?>    </label>
                                                <input type="text" value="<?php echo e(old('a2')); ?>" class="form-control" name="a2"
                                                    placeholder="    <?php echo e(__('sentences.a2')); ?>  " >
                                                <span class="form-text text-muted">
                                                    <?php echo e(__('sentences.enter_a2')); ?>

                                                     .</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>      <?php echo e(__('sentences.a3')); ?>    </label>
                                                <input type="text" value="<?php echo e(old('a3')); ?>" class="form-control" name="a3"
                                                    placeholder="   <?php echo e(__('sentences.a3')); ?> " >
                                                <span class="form-text text-muted">
                                                    <?php echo e(__('sentences.enter_a3')); ?>

                                                     .</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>      <?php echo e(__('sentences.a4')); ?>   </label>
                                                <input type="text" value="<?php echo e(old('a4')); ?>" class="form-control" name="a4"
                                                    placeholder="   <?php echo e(__('sentences.a4')); ?> " >
                                                <span class="form-text text-muted">
                                                    <?php echo e(__('sentences.enter_a4')); ?>

                                                     .</span>
                                                <div class="fv-plugins-message-container"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group fv-plugins-icon-container">
                                                <label>              <?php echo e(__('sentences.answer')); ?>      </label>
                                                <select name="answer" id="" class="form-control">
                                                    <option value="">  <?php echo e(__('sentences.select-one')); ?> </option>
                                                    <option  <?php echo e(old('answer')=='1'?'selected':''); ?> value="1"><?php echo e(__('sentences.g1')); ?></option>
                                                    <option  <?php echo e(old('answer')=='2'?'selected':''); ?> value="2">  <?php echo e(__('sentences.g2')); ?></option>
                                                    <option  <?php echo e(old('answer')=='3'?'selected':''); ?> value="3">  <?php echo e(__('sentences.g3')); ?></option>
                                                    <option  <?php echo e(old('answer')=='4'?'selected':''); ?> value="4">  <?php echo e(__('sentences.g4')); ?></option>
                                                </select>
                                            </div>
                                        </div>





                                    </div>


                                    <!--begin::ویزارد اقدامات-->
                                    <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                        
                                        <div>
                                            <input type="submit" value="  دخیره   "
                                                class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                                <a class="btn btn-danger font-weight-bold text-uppercase px-9 py-4" href="<?php echo e(route('quiz.question.index',[$quiz->id])); ?>">برکشت</a>


                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--end::ویزارد اقدامات-->
                        </form>


                        <!--end::ویزارد Form-->
                    </div>
                </div>
                <!--end::ویزارد Body-->
            </div>
            <!--end::ویزارد-->
        </div>
        <!--end::ویزارد-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\adyan\resources\views/admin/quiz/question/create.blade.php ENDPATH**/ ?>